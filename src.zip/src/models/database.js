const mongoose = require('mongoose');

const MONGO_URI = process.env.MONGO_URI;
if (!MONGO_URI) {
  console.error('FATAL: MONGO_URI environment variable is required');
  process.exit(1);
}
// ── Schemas ───────────────────────────────────────────────────────────────

const userSchema = new mongoose.Schema({
  _id:               { type: String },
  emp_id:            { type: String, unique: true, required: true },
  name:              { type: String, required: true },
  email:             { type: String, unique: true, required: true },
  password_hash:     { type: String, required: true },
  role:              { type: String, enum: ['employee', 'manager', 'admin', 'hr', 'super_admin', 'department_portal'], required: true },
  role_type:         { type: String, default: null },
  department:        { type: String, required: true },
  manager_id:        { type: String, ref: 'User', default: null },
 designation:  { type: String, default: null },
 hr_id:        { type: String, default: null },
  phone:             { type: String, default: null },
  is_active:         { type: Number, default: 1 },
  assigned_block:    { type: String, default: null },
  assigned_district: { type: String, default: null },
  // ── Email verification ───────────────────────────────────────────────
  email_verified:       { type: Boolean, default: false },
  email_verify_token:   { type: String,  default: null },  // hashed token
  email_verify_expires: { type: Date,    default: null },
  // ── Password reset ───────────────────────────────────────────────────
  pwd_reset_token:      { type: String,  default: null },  // hashed token
  pwd_reset_expires:    { type: Date,    default: null },
  // ── Password reset OTP ───────────────────────────────────────────────
  pwd_reset_otp:        { type: String,  default: null },  // hashed OTP
  pwd_reset_otp_expires:{ type: Date,    default: null },
  // ── Password changed timestamp (for global logout) ─────────────────
  pwd_changed_at:       { type: Date,    default: null },
  // ── Phone OTP ────────────────────────────────────────────────────────
  phone_otp:              { type: String,  default: null },  // hashed OTP
  phone_otp_expires:      { type: Date,    default: null },
  phone_otp_attempts:     { type: Number,  default: 0 },
  phone_otp_locked_until: { type: Date,    default: null },
  phone_verified:         { type: Boolean, default: false },
  // ── Account lockout ─────────────────────────────────────────────────
  failed_login_attempts: { type: Number, default: 0 },
  login_locked_until:    { type: Date, default: null },
  // ── Session management ───────────────────────────────────────────────
  active_session_jti:    { type: String, default: null },
// ── Profile Photo ─────────────────────────────────────────────────────────
profile_photo_path:      { type: String, default: null },  // Cloudinary URL
profile_photo_uploaded:  { type: Date,   default: null },  // when first uploaded
photo_update_quota:      { type: Number, default: null },  // null=locked, 0=unlimited, N=allowed N updates
photo_update_count:      { type: Number, default: 0    },  // how many updates used so far
  // Legacy single-scan fields kept for backwards compat
  scan_paper_path:     { type: String, default: null },
  scan_paper_uploaded: { type: String, default: null },
  face_enrolled: { type: Boolean, default: false },
  joining_date:                  { type: String, default: null },
  office_name:                   { type: String, default: null },
  reporting_officer_name:        { type: String, default: null },
  reporting_officer_designation: { type: String, default: null },
  // ── Leave management ─────────────────────────────────────────────────
  leave_balance:       { type: Number,  default: 0 },
  auto_leave_enabled:  { type: Boolean, default: true },
  last_accrual_date:   { type: String,  default: null }, // YYYY-MM-DD of last accrual run
  is_permitted:        { type: Boolean, default: false },
}, { timestamps: { createdAt: 'created_at', updatedAt: 'updated_at' } });

userSchema.index({ manager_id: 1 });
userSchema.index({ role: 1 });
userSchema.index({ is_active: 1 });

// ─────────────────────────────────────────────────────────────────────────────
// ATTENDANCE RECORD
// selfie_path          → Cloudinary URL (checkin photo)
// checkout_selfie_path → Cloudinary URL (checkout photo)
// reapply_docs         → Array of Cloudinary URLs
// ─────────────────────────────────────────────────────────────────────────────
const attendanceRecordSchema = new mongoose.Schema({
  _id:                  { type: String },
  emp_id:               { type: String, ref: 'User', required: true },
  date:                 { type: String, required: true },
  end_date:             { type: String, default: null },
  duty_type:            { type: String, enum: ['Office Duty', 'On Duty', 'On Duty Away', 'Leave'], required: true },
  sector:               { type: String, default: null },
  description:          { type: String, default: null },
  status:               { type: String, enum: ['Draft', 'Pending', 'Approved', 'Rejected'], default: 'Draft' },
  // ── Cloudinary URLs ──────────────────────────────────────────────────────
  selfie_path:          { type: String, default: null }, // Cloudinary secure URL
  checkout_selfie_path: { type: String, default: null }, // Cloudinary secure URL
  // ────────────────────────────────────────────────────────────────────────
  latitude:             { type: Number, default: null },
  longitude:            { type: Number, default: null },
  location_address:     { type: String, default: null },
  checkin_time:         { type: String, default: null },
  checkout_time:        { type: String, default: null },
  checkin_lat:          { type: Number, default: null },
  checkin_lng:          { type: Number, default: null },
  checkout_lat:         { type: Number, default: null },
  checkout_lng:         { type: Number, default: null },
  manager_id:           { type: String, ref: 'User', default: null },
  manager_remark:       { type: String, default: null },
  admin_remark:         { type: String, default: null },
  actioned_by:          { type: String, ref: 'User', default: null },
  actioned_at:          { type: Date, default: null },
  submitted_at:         { type: Date, default: null },
  worked_hours:         { type: Number, default: null },
  is_auto_checkout:     { type: Boolean, default: false },
  checkout_remarks:     { type: String, default: null },
  leave_type:           { type: String, enum: ['Casual Leave', 'Half Day', 'Emergency Leave', 'Urgent Leave', 'Planned Leave', null], default: null },
  attendance_type:      { type: String, enum: ['Regular', 'Irregular', 'Partial', 'Permitted', null], default: null },
  leave_reason:         { type: String, default: null },
  leave_status:         { type: String, enum: ['Pending', 'Approved', 'Rejected', null], default: null },
  reapply_reason:       { type: String, default: null },
  reapply_docs:         { type: [String], default: [] }, // Array of Cloudinary URLs
  reapplied_at:         { type: Date, default: null },
  hr_override:          { type: Boolean, default: false },
  hr_remark:            { type: String, default: null },
  hr_actioned_by:       { type: String, ref: 'User', default: null },
  hr_actioned_at:       { type: Date, default: null },
  overridden_by:        { type: String, enum: ['hr', 'super_admin', null], default: null },
  override_remark:      { type: String, default: null },
  face_verification_status: { type: String, enum: ['pending', 'retake_pending', 'verified', 'failed', 'manager_review', 'manager_approved', 'manager_rejected', null], default: null },
  face_confidence:          { type: Number, default: null },
  is_missed_checkout:       { type: Boolean, default: false },
  is_lop:                   { type: Boolean, default: false }, // Loss of Pay — balance was insufficient
  // ── Late check-out (6:30pm prompt) ─────────────────────────────────────
  // Set when the employee answers "No" to the 6:30pm "check out now?"
  // prompt and gives a reason instead. Extends their checkout window by
  // 15–20 min and is surfaced to employee / manager / super_admin / hr.
  late_checkout_reason:         { type: String, default: null },
  late_checkout_requested_at:   { type: Date,   default: null },
  late_checkout_extended_until: { type: Date,   default: null },
signed_reports: [{
    path:        String,
    name:        String,
    month:       String,   // "YYYY-MM"
    month_label: String,   // "April 2026"
    uploaded_at: Date,
    uploaded_by: String,   // user _id
  }]
}, { timestamps: { createdAt: 'created_at', updatedAt: 'updated_at' } });

attendanceRecordSchema.index({ emp_id: 1, date: 1 }, { unique: true });
attendanceRecordSchema.index({ date: 1 });
attendanceRecordSchema.index({ status: 1 });
attendanceRecordSchema.index({ manager_id: 1 });
attendanceRecordSchema.index({ manager_id: 1, status: 1 });
attendanceRecordSchema.index({ date: 1, status: 1 });

// ─────────────────────────────────────────────────────────────────────────────

const notificationSchema = new mongoose.Schema({
  _id:               { type: String },
  user_id:           { type: String, ref: 'User', required: true },
  title:             { type: String, required: true },
  message:           { type: String, required: true },
  type:              { type: String, enum: ['info', 'success', 'warning', 'error'], default: 'info' },
  is_read:           { type: Number, default: 0 },
  related_record_id: { type: String, ref: 'AttendanceRecord', default: null },
  link:              { type: String, default: null },
}, { timestamps: { createdAt: 'created_at', updatedAt: false } });

notificationSchema.index({ user_id: 1 });
notificationSchema.index({ user_id: 1, is_read: 1 });

const auditLogSchema = new mongoose.Schema({
  _id:         { type: String },
  user_id:     { type: String, ref: 'User', required: true },
  action:      { type: String, required: true },
  entity_type: { type: String, default: null },
  entity_id:   { type: String, default: null },
  old_value:   { type: String, default: null },
  new_value:   { type: String, default: null },
  ip_address:  { type: String, default: null },
}, { timestamps: { createdAt: 'created_at', updatedAt: false } });

auditLogSchema.index({ entity_type: 1, entity_id: 1 });
auditLogSchema.index({ user_id: 1 });
auditLogSchema.index({ created_at: 1 });

const revokedTokenSchema = new mongoose.Schema({
  _id:        { type: String },
  revoked_at: { type: Date, default: Date.now },
});

const activitySchema = new mongoose.Schema({
  _id:               { type: String },
  user_id:           { type: String, ref: 'User', required: true },
  msme_name:         { type: String, required: true },
  udyam_number:      { type: String, default: null },
  // Legacy fields kept for backwards compatibility
  sector:            { type: String, default: null },
  support_type:      { type: String, default: null },
  // New hierarchical activity classification
  activity_type:     { type: String, default: null },
  sub_activity:      { type: String, default: null },
  // MSME address (auto-filled from master when available)
  msme_address:      { type: String, default: null },
  district:          { type: String, default: null },
  block_name:        { type: String, required: true },
  latitude:          { type: Number, default: null },
  longitude:         { type: Number, default: null },
  location_address:  { type: String, default: null },
  activity_date:     { type: String, required: true },
  remarks:           { type: String, default: null },
  // Resolution & outcome fields
  resolved_solution: { type: String, default: null },
  end_results:       { type: String, default: null },
  resource_type:     { type: String, default: null }, // 'image' | 'raw'
}, { timestamps: { createdAt: 'created_at', updatedAt: 'updated_at' } });

activitySchema.index({ user_id: 1 });
activitySchema.index({ activity_date: 1 });
activitySchema.index({ block_name: 1 });
activitySchema.index({ sector: 1 });
activitySchema.index({ activity_date: 1, block_name: 1 });

// MSME Master — pre-loaded list of registered MSMEs per block
const msmeMasterSchema = new mongoose.Schema({
  _id:          { type: String },
  msme_name:    { type: String, required: true },
  udyam_number: { type: String, required: true, unique: true },
  sector:       { type: String, default: null },
  block_name:   { type: String, required: true },
  district:     { type: String, required: true },
  address:      { type: String, default: null },   // Full address from Udyam registration
  owner_name:   { type: String, default: null },
  contact:      { type: String, default: null },
  latitude:     { type: Number, default: null },
  longitude:    { type: Number, default: null },
  nic_code:     { type: String, default: null },
  is_active:    { type: Boolean, default: true },
}, { timestamps: { createdAt: 'created_at', updatedAt: 'updated_at' }, collection: 'msme_masters' });

msmeMasterSchema.index({ block_name: 1 });
msmeMasterSchema.index({ district: 1 });
msmeMasterSchema.index({ sector: 1 });
msmeMasterSchema.index({ is_active: 1 });

// ─────────────────────────────────────────────────────────────────────────────
// MSME PROPOSALS — new MSMEs submitted by employees for admin review
// ─────────────────────────────────────────────────────────────────────────────
const msmePropSchema = new mongoose.Schema({
  _id:          { type: String },
  msme_name:    { type: String, required: true },
  address:      { type: String, default: null },
  city:         { type: String, default: null },
  pincode:      { type: String, default: null },
  state:        { type: String, default: null },
  district:     { type: String, default: null },
  block_name:   { type: String, default: null },
  latitude:     { type: Number, default: null },
  longitude:    { type: Number, default: null },
  proposed_by:  { type: String, default: null }, // emp_id
  status:       { type: String, enum: ['pending', 'approved', 'rejected'], default: 'pending' },
}, { timestamps: true, collection: 'msme_proposals' });

const MsmeProposal = mongoose.model('MsmeProposal', msmePropSchema);

// ─────────────────────────────────────────────────────────────────────────────
// ACTIVITY DOCUMENT
// file_path  → Cloudinary secure URL (was: local filename like act_userid_123.jpg)
// public_id  → Cloudinary public_id for deletion (NEW field)
// ─────────────────────────────────────────────────────────────────────────────
const activityDocumentSchema = new mongoose.Schema({
  _id:         { type: String },
  activity_id: { type: String, ref: 'Activity', required: true },
  file_path:   { type: String, required: true }, // Cloudinary secure URL
  file_name:   { type: String, required: true }, // original filename
  file_type:   { type: String, default: null  }, // mimetype
  public_id:   { type: String, default: null  }, // ← NEW: Cloudinary public_id for deletion
  resource_type: { type: String }, // 'image' | 'raw'
}, { timestamps: { createdAt: 'created_at', updatedAt: false } });

activityDocumentSchema.index({ activity_id: 1 });

// ─────────────────────────────────────────────────────────────────────────────
// ACTIVITY SCHEDULE
// ─────────────────────────────────────────────────────────────────────────────
const activityScheduleSchema = new mongoose.Schema({
  _id:              { type: String },
  title:            { type: String, required: true },
  description:      { type: String, default: null },
  scheduled_date:   { type: String, required: true },
  location:         { type: String, default: null },
  assigned_to:      { type: String, ref: 'User', default: null },
  manager_id:       { type: String, ref: 'User', default: null },
  created_by:       { type: String, ref: 'User', required: true },
  assigned_by:      { type: String, ref: 'User', default: null }, // who assigned this activity
  assigned_by_name: { type: String, default: null },               // quick-display name
  manager_id:       { type: String, ref: 'User', default: null }, // selected manager
  status:           { type: String, enum: ['Pending', 'Initiated', 'Completed'], default: 'Pending' },
  initiated_by:     { type: String, ref: 'User', default: null },
  initiated_at:     { type: Date, default: null },
  completed_by:     { type: String, ref: 'User', default: null },
  completed_at:     { type: Date, default: null },
  work_description: { type: String, default: null },
  remarks:          { type: String, default: null },
}, { timestamps: { createdAt: 'created_at', updatedAt: 'updated_at' } });

activityScheduleSchema.index({ scheduled_date: 1 });
activityScheduleSchema.index({ status: 1 });
activityScheduleSchema.index({ assigned_to: 1 });
activityScheduleSchema.index({ created_by: 1 });
activityScheduleSchema.index({ manager_id: 1 });

// ─────────────────────────────────────────────────────────────────────────────
// SCHEDULE DOCUMENT
// file_path  → Cloudinary secure URL (was: schedule/sched_userid_123.jpg)
// public_id  → Cloudinary public_id for deletion (NEW field)
// ─────────────────────────────────────────────────────────────────────────────
const scheduleDocumentSchema = new mongoose.Schema({
  _id:         { type: String },
  schedule_id: { type: String, ref: 'ActivitySchedule', required: true },
  file_path:   { type: String, required: true }, // Cloudinary secure URL
  file_name:   { type: String, required: true }, // original filename
  file_type:   { type: String, default: null  }, // mimetype
  public_id:   { type: String, default: null  }, // ← NEW: Cloudinary public_id for deletion
  resource_type: { type: String }, // 'image' | 'raw'
}, { timestamps: { createdAt: 'created_at', updatedAt: false } });

scheduleDocumentSchema.index({ schedule_id: 1 });
const monthlyReportSchema = new mongoose.Schema({
  user_id:     { type: String, ref: 'User', required: true },
  month_key:   { type: String, required: true },      // "2026-06"
  file_name:   { type: String, required: true },
  file_type:   { type: String, default: null },
  file_url:    { type: String, required: true },      // Cloudinary URL
  public_id:   { type: String, default: null },       // for Cloudinary deletion
  uploaded_at: { type: Date, default: Date.now },
  // expires_at removed — reports are kept forever, deletion is manual only (see DELETE routes)
}, { timestamps: { createdAt: 'created_at', updatedAt: false } });

monthlyReportSchema.index({ user_id: 1, month_key: 1 }, { unique: true });

// ── Models ────────────────────────────────────────────────────────────────

const User             = mongoose.model('User',             userSchema);
const AttendanceRecord = mongoose.model('AttendanceRecord', attendanceRecordSchema);
const Notification     = mongoose.model('Notification',     notificationSchema);
const AuditLog         = mongoose.model('AuditLog',         auditLogSchema);
const RevokedToken     = mongoose.model('RevokedToken',     revokedTokenSchema);
const Activity         = mongoose.model('Activity',         activitySchema);
const ActivityDocument = mongoose.model('ActivityDocument', activityDocumentSchema);
const ActivitySchedule = mongoose.model('ActivitySchedule', activityScheduleSchema);
const ScheduleDocument = mongoose.model('ScheduleDocument', scheduleDocumentSchema);
const MsmeMaster       = mongoose.model('MsmeMaster',       msmeMasterSchema);
const MonthlyReport    = mongoose.model('MonthlyReport',    monthlyReportSchema);
// ── Custom Dropdown Options (shared across all users) ─────────────────────
const customOptionSchema = new mongoose.Schema({
  _id:      { type: String },
  category: { type: String, required: true, index: true },  // e.g. 'ams_custom_activity_types'
  value:    { type: String, required: true },
  added_by: { type: String, ref: 'User', default: null },
}, { timestamps: true });
customOptionSchema.index({ category: 1, value: 1 }, { unique: true });
const CustomOption = mongoose.model('CustomOption', customOptionSchema);

// ── Custom Blocks (admin-managed, merged with hardcoded base list) ─────────
const customBlockSchema = new mongoose.Schema({
  district:   { type: String, required: true },
  block_name: { type: String, required: true },
  added_by:   { type: String, ref: 'User', default: null },
}, { timestamps: true });
customBlockSchema.index({ district: 1, block_name: 1 }, { unique: true });
const CustomBlock = mongoose.model('CustomBlock', customBlockSchema);

// ── Department Master ──────────────────────────────────────────────────────
const customDepartmentSchema = new mongoose.Schema({
  name:     { type: String, required: true, unique: true },
  added_by: { type: String, ref: 'User', default: null },
}, { timestamps: { createdAt: 'created_at', updatedAt: false } });

const CustomDepartment = mongoose.model('CustomDepartment', customDepartmentSchema);

// ── Geocode Cache ─────────────────────────────────────────────────────────
const geoCacheSchema = new mongoose.Schema({
  key:     { type: String, unique: true, required: true }, // "lat2dp,lng2dp"
  payload: { type: mongoose.Schema.Types.Mixed, required: true },
}, { timestamps: { createdAt: 'created_at', updatedAt: false } });

const GeoCache = mongoose.model('GeoCache', geoCacheSchema);

// ── Holiday Master ────────────────────────────────────────────────────────
const holidaySchema = new mongoose.Schema({
  date:     { type: String, required: true, unique: true }, // 'YYYY-MM-DD'
  name:     { type: String, required: true },
  type:     { type: String, enum: ['public', 'state', 'restricted'], default: 'public' },
  added_by: { type: String, ref: 'User', default: null },
}, { timestamps: { createdAt: 'created_at', updatedAt: 'updated_at' } });
holidaySchema.index({ date: 1 });
const Holiday = mongoose.model('Holiday', holidaySchema);

// ── ODA (On-Duty Away) Requests ────────────────────────────────────────────
const odaRequestSchema = new mongoose.Schema({
  _id:           { type: String },
  emp_id:        { type: String, ref: 'User', required: true },
  from_date:     { type: String, required: true },   // 'YYYY-MM-DD'
  to_date:       { type: String, required: true },   // 'YYYY-MM-DD'
  duty_type:     { type: String, enum: ['Training', 'Head Office Visit', 'District Meeting', 'Election Duty', 'Other'], required: true },
  location_name: { type: String, required: true },
  reason:        { type: String, required: true },
  status:        { type: String, enum: ['pending', 'approved', 'rejected'], default: 'pending' },
  approved_by:   { type: String, ref: 'User', default: null },
  admin_remark:  { type: String, default: null },
  actioned_at:   { type: Date, default: null },
}, { timestamps: { createdAt: 'created_at', updatedAt: 'updated_at' } });
odaRequestSchema.index({ emp_id: 1, status: 1 });
odaRequestSchema.index({ from_date: 1, to_date: 1 });
odaRequestSchema.index({ status: 1 });
const ODARequest = mongoose.model('ODARequest', odaRequestSchema);

// ── Connect ───────────────────────────────────────────────────────────────

const connectionPromise = mongoose.connect(MONGO_URI, {
  maxPoolSize:             100,
  minPoolSize:               5,
  serverSelectionTimeoutMS: 8000,
  socketTimeoutMS:          45000,
  connectTimeoutMS:         10000,
  heartbeatFrequencyMS:     10000,
  retryWrites:               true,
  retryReads:                true,
})
  .then(() => console.log('✅ MongoDB Atlas connected (pool: 5–100)'))
  .catch(err => { console.error('❌ MongoDB connection error:', err); process.exit(1); });

module.exports = {
  User,
  AttendanceRecord,
  Notification,
  AuditLog,
  RevokedToken,
  Activity,
  ActivityDocument,
  MsmeMaster,
  MsmeProposal,
  CustomOption,
  CustomBlock,
  connectionPromise,
  ActivitySchedule,
  ScheduleDocument,
  GeoCache,
  CustomDepartment,
  ODARequest,
  MonthlyReport,
  Holiday,
};