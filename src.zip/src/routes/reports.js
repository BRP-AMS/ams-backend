/**
 * src/routes/reports.js
 *
 * P/OD logic (location-based, per employee assignment):
 *   - Employee has NO assigned_block/assigned_district → always P (default)
 *   - Employee HAS assignment:
 *       check-in location matches assigned_block or assigned_district → P
 *       check-in location is in ANY Tripura block/district (but not assigned) → OD
 *       check-in location is outside ALL known blocks/districts → '' (blank)
 *
 * Cell codes:
 *   P       = Present at assigned location        → no colour
 *   OD      = On Duty at other Tripura location    → no colour
 *   L       = Leave (approved) OR rejected leave with no re-check-in → RED
 *   A       = Absent (no check-in, after join)     → RED
 *   WO      = Weekend                              → light blue
 *   LOC_ERR = Checked in but GPS/network failed to capture a location →
 *             rendered as the location-pin-with-alert icon (pin_error.png),
 *             falls back to a red "!" text marker if the asset is missing
 *   ""      = Blank (future / pre-join / outside all known locations /
 *             leave still pending manager action)
 *
 * Leave status logic (UPDATED — see toCode()):
 *   leave_status === 'Pending'  → blank, for EVERY leave type. No code is
 *                                 shown until the manager approves/rejects it.
 *   leave_status === 'Approved' → L, unconditionally. A Half Day (or any
 *                                 other type) that was later checked in used
 *                                 to fall through to P/OD — it no longer does.
 *   leave_status === 'Rejected' + no re-check-in → L  (LOP)
 *   leave_status === 'Rejected' + re-checked in  → P / OD (normal attendance)
 *
 * endDate always capped to yesterday for ATTENDANCE exports (today is incomplete)
 * Leave exports: NO cap — leaves are complete records
 * Signature row: Employee Sign (left) + Manager Sign (right) — side by side
 *
 * Override mutex:
 *   After manager acts, EITHER hr OR super_admin can override (first-wins).
 *   Once one party overrides, the other sees the remark but cannot override again.
 */
'use strict';

const express  = require('express');
const router   = express.Router();
const ExcelJS  = require('exceljs');
const PDFDoc   = require('pdfkit');
const mongoose = require('mongoose');
const { AttendanceRecord, User } = require('../models/database');
const { authenticate, authorize } = require('../middleware/auth');
const fs       = require('fs');
const path     = require('path');
const PIN_ERROR_PNG_PATH = path.join(__dirname, '../assets/pin_error.png');
// Load defensively — a missing/renamed asset should degrade to the 'LOC_ERR'
// text code instead of crashing the whole reports router at require-time.
let PIN_ERROR_PNG_BUFFER = null;
try {
  PIN_ERROR_PNG_BUFFER = fs.readFileSync(PIN_ERROR_PNG_PATH);
} catch (e) {
  console.error('[reports.js] pin_error.png not found — LOC_ERR cells will fall back to text.', e.message);
}

// ── Tripura blocks & districts ────────────────────────────────────────────────
const TRIPURA_BLOCKS = [
  'Agartala','Amarpur','Ambassa','Bagafa','Belonia','Bishalgarh','Boxanagar',
  'Dhalai','Dharmanagar','Gandacherra','Jampui Hills','Jolaibari','Jirania',
  'Kakraban','Kamalpur','Kanchanpur','Karbook','Khowai','Lefunga',
  'Longtarai Valley','Majlishpur','Matarbari','Melaghar','Mohanpur',
  'Mungiakami','Murasingh','Nasingh Para','Padmabil','Panisagar',
  'Ramchandraghat','Rupaichari','Sabroom','Salema','Sonamura','Surma','Teliamura',
];
const TRIPURA_DISTRICTS = [
  'Dhalai','Gomati','Khowai','North Tripura','Sipahijala',
  'South Tripura','Unakoti','West Tripura',
];
const ALL_TRIPURA = [...TRIPURA_BLOCKS, ...TRIPURA_DISTRICTS, 'Tripura'];

const isInTripura = addr => {
  if (!addr) return false;
  const a = addr.toLowerCase();
  return ALL_TRIPURA.some(loc => a.includes(loc.toLowerCase()));
};

const matchesLocation = (addr, locationName) => {
  if (!addr || !locationName) return false;
  return addr.toLowerCase().includes(locationName.toLowerCase());
};
const https = require('https');
const _geocodeCache = new Map(); // "lat,lng" (4dp) -> address string

const _roundCoord = n => Math.round(Number(n) * 10000) / 10000; // ~11m precision, good cache hit rate

const reverseGeocode = (lat, lng) => new Promise(resolve => {
  if (lat == null || lng == null || isNaN(lat) || isNaN(lng)) return resolve('');
  const rLat = _roundCoord(lat), rLng = _roundCoord(lng);
  const key = `${rLat},${rLng}`;
  if (_geocodeCache.has(key)) return resolve(_geocodeCache.get(key));

  const url = `https://nominatim.openstreetmap.org/reverse?format=jsonv2&lat=${rLat}&lon=${rLng}&zoom=17&addressdetails=0`;
  const req = https.get(url, { headers: { 'User-Agent': 'RAMP-AMS/1.0 (attendance reports)' }, timeout: 4000 }, resp => {
    let data = '';
    resp.on('data', c => data += c);
    resp.on('end', () => {
      try {
        const parsed = JSON.parse(data);
        const addr = parsed?.display_name || '';
        _geocodeCache.set(key, addr);
        resolve(addr);
      } catch { resolve(''); }
    });
  });
  req.on('error', () => resolve(''));
  req.on('timeout', () => { req.destroy(); resolve(''); });
});
const buildLocationText = async (storedAddress, lat, lng) => {
  const hasCoords = lat != null && lng != null && !isNaN(lat) && !isNaN(lng);
  const coordStr  = hasCoords ? `${Number(lat).toFixed(5)}, ${Number(lng).toFixed(5)}` : '';

  // If the stored address already looks like real text (not just numbers/coords), use it.
  const looksLikeRawCoords = storedAddress && /^-?\d+\.\d+,\s*-?\d+\.\d+$/.test(storedAddress.trim());
  let addressText = (storedAddress && !looksLikeRawCoords) ? storedAddress.trim() : '';

  if (!addressText && hasCoords) {
    addressText = await reverseGeocode(lat, lng);
  }

  if (addressText && coordStr) return `${addressText} (${coordStr})`;
  if (addressText)             return addressText;
  if (coordStr)                return coordStr;
  return '';
};
// ── IST helpers ───────────────────────────────────────────────────────────────
const IST      = 'Asia/Kolkata';
const todayIST = () => new Date().toLocaleDateString('en-CA', { timeZone: IST });
const toObjId  = id => { try { return new mongoose.Types.ObjectId(String(id)); } catch { return id; } };
const yesterdayIST = () => {
  const d = new Date(); d.setDate(d.getDate()-1);
  return d.toLocaleDateString('en-CA', { timeZone: IST });
};

const expandDates = (start, end) => {
  const out = [];
  let cur = new Date(start+'T00:00:00+05:30');
  const fin = new Date(end +'T00:00:00+05:30');
  while (cur <= fin) {
    out.push(cur.toLocaleDateString('en-CA', { timeZone: IST }));
    cur.setDate(cur.getDate()+1);
  }
  return out;
};

const HOLIDAYS_MMDD = new Set([
  '01-14','01-23','01-26','03-04','03-21','04-03','04-14','04-15','04-21',
  '05-01','05-26','05-27','06-26','07-22','08-04','08-15','08-19','08-26',
  '09-04','10-02','10-17','10-19','10-20','10-21','10-22','10-23','10-26',
  '11-09','12-25',
]);
const RESTRICTED_MMDD = new Set([
  '01-01','03-03','03-25','03-31','06-20','07-16','08-12','08-28',
  '09-11','09-18','11-11','11-24','12-03','12-24',
]);

const isHoliday = iso => {
  const mmdd = iso.substring(5);
  return HOLIDAYS_MMDD.has(mmdd) || RESTRICTED_MMDD.has(mmdd);
};

const getNthSaturday = iso => {
  const d = new Date(iso + 'T00:00:00+05:30');
  if (d.getDay() !== 6) return 0;
  let count = 0;
  for (let i = 1; i <= d.getDate(); i++) {
    if (new Date(d.getFullYear(), d.getMonth(), i).getDay() === 6) count++;
  }
  return count;
};

const isNonWorkingDay = iso => {
  const dow = new Date(iso + 'T00:00:00+05:30').getDay();
  if (dow === 0) return true;                          // Sunday
  if (dow === 6) return true;
  return false;
};

const isWeekend = iso => isNonWorkingDay(iso); // kept for PDF total WO count
const dayNum    = iso => new Date(iso+'T00:00:00+05:30').getDate();
const monAbbr   = iso => new Date(iso+'T00:00:00+05:30').toLocaleDateString('en-IN',{timeZone:IST,month:'short'});
const dayAbbr   = iso => new Date(iso+'T00:00:00+05:30').toLocaleDateString('en-IN',{timeZone:IST,weekday:'short'});
const ordinal   = n   => { const s=['th','st','nd','rd'],v=n%100; return n+(s[(v-20)%10]||s[v]||s[0]); };
const colLetter = n   => { let s='',c=n; while(c>0){s=String.fromCharCode(65+(c-1)%26)+s;c=Math.floor((c-1)/26);} return s; };

/**
 * toCode — determines cell code for one attendance record
 */
// ── reports.js  ·  toCode() ───────────────────────────────────────────────
// UPDATED LOGIC (see also excel/PDF summary + legend below, which mirror this):
//   • Pending leave  → '' (blank). No code is shown until the manager takes
//     action — applies to every leave type (Half Day, Emergency, Casual, ...).
//     Still counted separately in the summary as "Leave Applied / Pending".
//   • Approved leave → ALWAYS 'L'. This is unconditional now — a Half Day
//     (or any other type) that was later checked in used to fall through to
//     P/OD; it no longer does. Any approved leave record renders as 'L'.
//   • Rejected leave with no re-check-in → 'L' (LOP — counted against the
//     employee, same visual as a normal approved leave).
//   • Rejected leave WITH a re-check-in → falls through to normal attendance
//     (the employee actually came in after the rejection).
//   • Checked in but GPS/network failed to capture a usable address → 'LOC_ERR'
//     (rendered as the location-pin-with-alert icon, not a text code — see
//     `PIN_ERROR_PNG_BUFFER` usage below).
const toCode = (rec, assignedBlock, assignedDistrict) => {
  if (!rec) return 'A';

  // ── Leave records ──────────────────────────────────────────────────────────
  const isLeave = rec.duty_type === 'Leave' || (rec.leave_type && String(rec.leave_type).trim());
  if (isLeave) {
    const ls = rec.leave_status || rec.status || 'Pending';

    // Pending — no manager decision yet → blank cell (all leave types).
    if (ls === 'Pending') return '';

    // Approved — always 'L', regardless of leave type or a later check-in.
    if (ls === 'Approved') return 'L';

    if (ls === 'Rejected') {
      const hasCheckin = rec.checkin_time || rec.checkinTime;
      if (!hasCheckin) return 'L';   // rejected, no re-checkin = LOP, shown as 'L'
      // Has a real check-in after rejection → falls through to normal attendance
    }
  }

  // ── Regular attendance ─────────────────────────────────────────────────────
  if (rec.status === 'Rejected') return 'A';

  // duty_type drives P vs OD — location is only a fallback
  const dutyType = (rec.duty_type || '').trim();

  if (dutyType === 'On Duty') return 'OD';   // employee chose "On Duty (Field)"

  // dutyType === 'Office Duty' (or blank/unknown) → location-based check
  const addr = rec.location_address || rec.locationAddress || '';

  // No assignment → always P
  if (!assignedBlock && !assignedDistrict) return 'P';

  const matchesAssigned =
    (assignedBlock    && matchesLocation(addr, assignedBlock))   ||
    (assignedDistrict && matchesLocation(addr, assignedDistrict));

  if (matchesAssigned)   return 'P';    // at assigned workplace
  if (isInTripura(addr)) return 'OD';   // elsewhere in Tripura (location fallback)

  // Check-in didn't resolve to the assigned location or anywhere in Tripura —
  // covers: GPS/network failed at check-in (no address captured), employee
  // didn't grant location permission, or the resolved address is genuinely
  // outside all known blocks/districts. All of these get the same icon.
  return 'LOC_ERR';
};
// ══════════════════════════════════════════════════════════════════════════════
//  GET /api/reports/export
//  Attendance matrix export (Excel / PDF)
//  Supports:  empId, managerId  query params for HR / super_admin filtered downloads
// ══════════════════════════════════════════════════════════════════════════════
router.get('/export',
  authenticate,
  authorize('super_admin','admin','hr','manager','employee'),
  async (req, res) => {
  try {
    const { format='excel', status, empId, managerId } = req.query;
    const role = req.user.role;
    let { startDate, endDate } = req.query;

    if (!startDate||!endDate)
      return res.status(400).json({success:false,message:'startDate and endDate are required'});

    // Cap endDate to yesterday — today is never shown (incomplete day)
    if (endDate >= todayIST()) endDate = yesterdayIST();
    if (startDate > endDate)
      return res.status(400).json({success:false,message:'No completed dates in range. Report covers up to yesterday.'});

    const dates      = expandDates(startDate, endDate);
    const multiMonth = new Date(startDate+'T00:00:00+05:30').getMonth() !==
                       new Date(endDate  +'T00:00:00+05:30').getMonth();
    const totalDays  = dates.length;
 const woCount    = dates.filter(isNonWorkingDay).length;
    const holCount   = dates.filter(d => !isNonWorkingDay(d) && isHoliday(d)).length;
    // ── Employee list ──────────────────────────────────────────────────────────
    // Priority: employee (own) → specific empId → managerId team → manager (own team) → all
    let employees = [];

    const EMP_SELECT = '_id name emp_id created_at assigned_block assigned_district role_type designation';

    if (role === 'employee') {
      // Always own record only
      const me = await User.findById(req.user.id)
        .select(EMP_SELECT).lean();
      if (me) employees = [me];

    } else if (empId && String(empId).trim() !== '') {
      // Specific employee selected in dropdown (any privileged role)
      const specific = await User.findById(toObjId(empId))
        .select(EMP_SELECT).lean();
      if (specific) employees = [specific];
      else return res.status(404).json({success:false,message:'Selected employee not found'});

    } else if (managerId && String(managerId).trim() !== '') {
      // Manager's entire team selected (HR / super_admin / admin use-case)
      employees = await User.find({ manager_id:toObjId(managerId), is_active:{$ne:false} })
        .select(EMP_SELECT).sort({emp_id:1}).lean();

    } else if (role === 'manager') {
      // Manager viewing own team
      employees = await User.find({ manager_id:toObjId(req.user.id), is_active:{$ne:false} })
        .select(EMP_SELECT).sort({emp_id:1}).lean();

    } else {
      // admin / hr / super_admin — all employees
      employees = await User.find({ role:'employee', is_active:{$ne:false} })
        .select(EMP_SELECT).sort({emp_id:1}).lean();
    }

    if (!employees.length)
      return res.status(404).json({success:false,message:'No employees found'});

    // ── Manager / Reporting Officer name for signature ──────────────────────────
    let managerName = '';
    if (role === 'manager') {
      const mgr = await User.findById(req.user.id).select('name').lean();
      managerName = mgr?.name || '';
    } else if (role === 'employee') {
      // FIX: employee's own download must show their Reporting Officer
      // (set on the employee's profile page), NOT the assigned BRP manager.
      const emp = await User.findById(req.user.id)
        .select('reporting_officer_name reporting_officer_designation').lean();
      managerName = emp?.reporting_officer_name
        ? (emp.reporting_officer_designation
            ? `${emp.reporting_officer_designation}. ${emp.reporting_officer_name}`
            : emp.reporting_officer_name)
        : '';
    } else if (managerId && String(managerId).trim() !== '') {
      // HR/super_admin filtered by a specific manager — show that manager's name
      const mgr = await User.findById(toObjId(managerId)).select('name').lean();
      managerName = mgr?.name || '';
    }
    // admin/hr/super_admin without manager filter → no single manager; leave blank

    // ── Attendance records ─────────────────────────────────────────────────────
    const recFilter = {
      date:   {$gte:startDate,$lte:endDate},
      emp_id: {$in:employees.map(e=>e._id)},
    };
    if (status && status !== 'All') recFilter.status = status;
    const rawRecs = await AttendanceRecord.find(recFilter).sort({date:1}).lean();

    // Build index — prefer real check-in records over rejected leave records for the same date
    const recIdx = {};
    for (const r of rawRecs) {
      const eid = String(r.emp_id);
      if (!recIdx[eid]) recIdx[eid] = {};
      const existing = recIdx[eid][r.date];
      const existingIsRejectedLeave =
        existing &&
        (existing.duty_type === 'Leave' || (existing.leave_type && String(existing.leave_type).trim())) &&
        (existing.leave_status === 'Rejected' || existing.status === 'Rejected');
      // Replace if no existing record, or if existing is a rejected leave (prefer real check-in)
      if (!existing || existingIsRejectedLeave) {
        recIdx[eid][r.date] = r;
      }
    }

    // ── Build cell matrix ──────────────────────────────────────────────────────
    const matrix = employees.map(emp => {
      const joinDate = emp.created_at
        ? new Date(emp.created_at).toLocaleDateString('en-CA', { timeZone: IST })
        : null;
      const ab = emp.assigned_block    || null;
      const ad = emp.assigned_district || null;

    return {
        emp,
        cells: dates.map(iso => {
          if (isNonWorkingDay(iso))           return 'WO'; // Sunday or 2nd/4th Sat
          if (joinDate && iso < joinDate)     return '';   // pre-join → blank
          if (isHoliday(iso))                 return 'H';  // public holiday
          const rec = recIdx[String(emp._id)]?.[iso];
          return toCode(rec, ab, ad);
        }),
      };
    });

    const sd = new Date(startDate+'T00:00:00+05:30');
    const ed = new Date(endDate  +'T00:00:00+05:30');
    const rangeTitle =
      `for the period ${ordinal(sd.getDate())} ` +
      `${sd.toLocaleDateString('en-IN',{timeZone:IST,month:'short'})}- ${sd.getFullYear()} To ` +
      `${ordinal(ed.getDate())} ${ed.toLocaleDateString('en-IN',{timeZone:IST,month:'long'})} ${ed.getFullYear()}`;

    // ══════════════════════════════════════════════════════════════════════════
    //  EXCEL
    // ══════════════════════════════════════════════════════════════════════════
    if (format==='excel') {
      const wb = new ExcelJS.Workbook(); wb.creator='RAMP AMS';

      const FILL_RED  = {type:'pattern',pattern:'solid',fgColor:{argb:'FFFF4444'}};
      const FILL_WO   = {type:'pattern',pattern:'solid',fgColor:{argb:'FFBDD7EE'}};
      const FILL_WHT  = {type:'pattern',pattern:'solid',fgColor:{argb:'FFFFFFFF'}};
      const FILL_ALT  = {type:'pattern',pattern:'solid',fgColor:{argb:'FFF7F7F7'}};
      const FILL_SUBH = {type:'pattern',pattern:'solid',fgColor:{argb:'FFE8EDF4'}};
const FILL_HOL  = {type:'pattern',pattern:'solid',fgColor:{argb:'FFFFF3CD'}};
      const codeFill = (code, rf) => {
        if (code==='L'||code==='A') return FILL_RED;
        if (code==='WO')            return FILL_WO;
        if (code==='H')             return FILL_HOL;
        if (code==='LOC_ERR')       return rf;   // neutral — icon carries the meaning
        return rf;
      };
    const TH  = ()=>({style:'thin',  color:{argb:'FFCCCCCC'}});
      const MED = ()=>({style:'medium',color:{argb:'FF999999'}});
      const CBDR = {top:TH(),bottom:TH(),left:TH(),right:TH()};
      const mc  = (ws,r1,c1,r2,c2)=>ws.mergeCells({top:r1,left:c1,bottom:r2,right:c2});
      const outerBorder = (ws,r1,c1,r2,c2)=>{
        for(let r=r1;r<=r2;r++) for(let c=c1;c<=c2;c++)
          ws.getCell(r,c).border={
            top:   r===r1?MED():TH(), bottom:r===r2?MED():TH(),
            left:  c===c1?MED():TH(), right: c===c2?MED():TH(),
          };
      };
  const buildSheet = (ws, empList, sheetTitle, mgrName,hCount=0) => {
        const LAST = 4+dates.length;
        const pinImgId = PIN_ERROR_PNG_BUFFER
          ? wb.addImage({ buffer: PIN_ERROR_PNG_BUFFER, extension: 'png' })
          : null;

        // ── Rows 1-3: header ──────────────────────────────────────────────────
        mc(ws,1,2,1,LAST);
        Object.assign(ws.getCell(1,2),{value:'Attendance details of BRP',font:{bold:true,size:13,name:'Calibri'},alignment:{horizontal:'center',vertical:'center'}});
        ws.getRow(1).height=24;

        mc(ws,2,2,2,LAST);
        Object.assign(ws.getCell(2,2),{value:rangeTitle,font:{bold:true,size:11,name:'Calibri'},alignment:{horizontal:'center',vertical:'center'}});
        ws.getRow(2).height=18;

        const half=2+Math.floor(dates.length/2);
        mc(ws,3,2,3,half-1);
        Object.assign(ws.getCell(3,2),{value:'Location Name: Tripura',font:{bold:true,size:10,name:'Calibri'},alignment:{horizontal:'left',vertical:'center'}});
        mc(ws,3,half,3,LAST);
        Object.assign(ws.getCell(3,half),{value:'Project Name: Block Resource Person',font:{bold:true,size:10,name:'Calibri'},alignment:{horizontal:'left',vertical:'center'}});
        ws.getRow(3).height=16;

        // ── Row 4: column headers ─────────────────────────────────────────────
        ws.getRow(4).height=multiMonth?38:26;
        ws.getColumn(2).width=9; ws.getColumn(3).width=16; ws.getColumn(4).width=14;
        const HF={bold:true,size:9,color:{argb:'FF3366FF'},name:'Calibri'};
        const setHdr=(col,val)=>{
          const c=ws.getCell(4,col); c.value=val; c.font=HF; c.fill=FILL_WHT; c.border=CBDR;
          c.alignment={horizontal:'center',vertical:'center',wrapText:col>4};
          ws.getColumn(col).width=col===2?9:col===3?16:col===4?14:4.2;
        };
        setHdr(2,'Emp code'); setHdr(3,'Employee Name'); setHdr(4,'Designation');
        dates.forEach((iso,i)=>setHdr(5+i,multiMonth?`${dayNum(iso)}\n${dayAbbr(iso)}\n${monAbbr(iso)}`:`${dayNum(iso)}\n${dayAbbr(iso)}`));

        // ── Data rows ─────────────────────────────────────────────────────────
        empList.forEach(({emp,cells},idx)=>{
          const rowN=5+idx; ws.getRow(rowN).height=15;
          const rf=idx%2===0?FILL_WHT:FILL_ALT;
          const c2=ws.getCell(rowN,2); c2.value=emp.emp_id; c2.border=CBDR; c2.fill=rf; c2.alignment={horizontal:'center',vertical:'center',wrapText:false}; c2.font={size:10,name:'Calibri'}; c2.protection={locked:true};
          const c3=ws.getCell(rowN,3); c3.value=emp.name;   c3.border=CBDR; c3.fill=rf; c3.alignment={horizontal:'left',  vertical:'center',wrapText:false}; c3.font={size:10,name:'Calibri'}; c3.protection={locked:true};
          const c4=ws.getCell(rowN,4); c4.value=emp.role_type||emp.designation||''; c4.border=CBDR; c4.fill=rf; c4.alignment={horizontal:'center',vertical:'center',wrapText:false}; c4.font={size:9,name:'Calibri'}; c4.protection={locked:true};
         cells.forEach((code,i)=>{
            const c=ws.getCell(rowN,5+i); c.border=CBDR;
            c.alignment={horizontal:'center',vertical:'center',wrapText:false};
            c.fill=codeFill(code,rf); c.protection={locked:true};

            if (code === 'LOC_ERR' && pinImgId != null) {
              c.value = '';
              ws.addImage(pinImgId, {
                tl: { col: (4+i) + 0.2, row: (rowN-1) + 0.12 },
                br: { col: (4+i) + 0.8, row: (rowN-1) + 0.88 },
                editAs: 'oneCell',
              });
            } else if (code === 'LOC_ERR') {
              // Icon asset missing — fall back to a plain text marker.
              c.value = '⚠';
              c.font  = { bold: true, size: 9, name: 'Calibri', color: { argb: 'FFDC2626' } };
            } else {
              c.value = code;
              c.font = {bold:!!code,size:9,name:'Calibri',color:{argb:(code==='L'||code==='A')?'FFFFFFFF':'FF000000'}};
            }
          });
        });

        // ── Legend ────────────────────────────────────────────────────────────
        const legendRow=5+empList.length+1; ws.getRow(legendRow).height=14;
       const FILL_AMB = {type:'pattern',pattern:'solid',fgColor:{argb:'FFFFF3CD'}};
        const legendItems = [
         {code:'P',label:'Present (assigned location)',isRed:false},
         {code:'OD',label:'On Duty (other Tripura location)',isRed:false},
         {code:'H',label:'Public Holiday',isRed:false,isAmber:true},
         {code:'L',label:'Leave / LOP',isRed:true},
         {code:'A',label:'Absent',isRed:true},
         {code:'WO',label:'Week Off',isRed:false},
         {code:'LOC_ERR',label:'Location not captured (GPS/network failed)',isRed:false,isIcon:true},
        ];
        legendItems.forEach(({code,label,isRed,isAmber,isIcon},i)=>{
          const cc=ws.getCell(legendRow,5+i*2);
          cc.border=CBDR;
          cc.alignment={horizontal:'center',vertical:'center'};
          if (isIcon && pinImgId != null) {
            cc.value=''; cc.fill=FILL_WHT;
            ws.addImage(pinImgId, {
              tl: { col: (4+i*2) + 0.15, row: (legendRow-1) + 0.05 },
              br: { col: (4+i*2) + 0.85, row: (legendRow-1) + 0.95 },
              editAs: 'oneCell',
            });
          } else if (isIcon) {
            cc.value='⚠'; cc.fill=FILL_WHT;
            cc.font={bold:true,size:8,name:'Calibri',color:{argb:'FFDC2626'}};
          } else {
            cc.value=code; cc.fill=isRed?FILL_RED:isAmber?FILL_AMB:FILL_WHT;
            cc.font={bold:true,size:8,name:'Calibri',color:{argb:isRed?'FFFFFFFF':isAmber?'FFD97706':'FF000000'}};
          }
          ws.getCell(legendRow,5+i*2+1).value=label;
          ws.getCell(legendRow,5+i*2+1).font={size:8,name:'Calibri',italic:true};
        });
        // NEW: a blank cell with no code (that isn't a weekend/holiday/pre-join
        // day) is a leave application still awaiting the manager's decision.
        const legendNoteRow = legendRow + 1;
        ws.getRow(legendNoteRow).height = 12;
        mc(ws, legendNoteRow, 5, legendNoteRow, LAST);
        Object.assign(ws.getCell(legendNoteRow, 5), {
          value: 'Blank cell (not WO/H) = Leave Applied — awaiting manager approval. Once approved it shows as L.',
          font: { size: 8, italic: true, color: { argb: 'FF64748B' }, name: 'Calibri' },
          alignment: { horizontal: 'left', vertical: 'center' },
        });
        // ── Summary ───────────────────────────────────────────────────────────
        const fDC=colLetter(5), lDC=colLetter(4+dates.length);
        let r=legendRow+2; const SR=r;
        ws.getColumn(2).width=28; ws.getColumn(3).width=12;
        const TF={bold:true,size:11,color:{argb:'FFC00000'},name:'Calibri'};
        const LF={bold:true,size:10,color:{argb:'FF1F3864'},name:'Calibri'};

        mc(ws,r,2,r,3);
        Object.assign(ws.getCell(r,2),{value:sheetTitle,fill:FILL_WHT,font:TF,alignment:{horizontal:'center',vertical:'center'}});
        ws.getRow(r).height=18;

        const sumRow=(label,value)=>{
          r++; ws.getRow(r).height=16;
          Object.assign(ws.getCell(r,2),{value:label,fill:FILL_WHT,font:LF,alignment:{horizontal:'left',vertical:'center'}});
          const vc=ws.getCell(r,3);
          const isF=typeof value==='string'&&value.startsWith('=');
          vc.value=isF?{formula:value.slice(1)}:value;
          vc.fill=FILL_WHT; vc.font=LF; vc.alignment={horizontal:'center',vertical:'center'}; vc.protection={locked:true};
        };

        sumRow('No of Total Days',totalDays);
        sumRow('No of Weekoff (WO)',woCount);
        sumRow('No of Holidays (H)',hCount);

        if(empList.length===1){
  const er=5;
  const empIdStr = String(empList[0].emp._id);

  // Pull this employee's leave-type records for the date range
  const empLeaveRecs = rawRecs.filter(r =>
    String(r.emp_id) === empIdStr &&
    (r.duty_type === 'Leave' || (r.leave_type && String(r.leave_type).trim()))
  );

  const byType = t => empLeaveRecs.filter(r => String(r.leave_type||'').toLowerCase().includes(t));
  const halfDayRecs   = byType('half');
  const emergencyRecs = byType('emergency');
  const casualRecs    = byType('casual');
  const pendingRecs   = empLeaveRecs.filter(r => (r.leave_status || r.status || 'Pending') === 'Pending');

  // Effective leave days: matches toCode()'s L logic, half-day counts as 0.5
  const effectiveLeaves = empLeaveRecs.reduce((sum, r) => {
    const ls = r.leave_status || r.status || 'Pending';
    if (ls === 'Pending') return sum;
    const isHalf = String(r.leave_type||'').toLowerCase().includes('half');
    const hasCheckin = r.checkin_time || r.checkinTime;
    if (ls === 'Approved') return sum + (isHalf ? 0.5 : 1); // approved leave always counts (matches toCode's unconditional 'L')
    if (ls === 'Rejected') return hasCheckin ? sum : sum + (isHalf ? 0.5 : 1);
    return sum;
  }, 0);
  const locErrCount = empList[0].cells.filter(c => c === 'LOC_ERR').length;
  sumRow('No of Present / worked (P+OD)', `=COUNTIF(${fDC}${er}:${lDC}${er},"P")+COUNTIF(${fDC}${er}:${lDC}${er},"OD")`);
  sumRow('No of Leaves (L)', `=COUNTIF(${fDC}${er}:${lDC}${er},"L")`);
  sumRow('No of Half Day Leaves (each = 0.5 day)', halfDayRecs.length);
  sumRow('No of Emergency Leaves', emergencyRecs.length);
  sumRow('No of Casual Leaves', casualRecs.length);
  sumRow('Total Effective Leaves', effectiveLeaves);
  sumRow('No of Absent (A)', `=COUNTIF(${fDC}${er}:${lDC}${er},"A")`);
  sumRow('No of Leave Applied / Pending (LA)', pendingRecs.length);
    sumRow('No of Location Not Captured', locErrCount);
}else {
          // ── Table header row ────────────────────────────────────────────────
          r++; ws.getRow(r).height = 17;
          ws.getColumn(2).width = 22; ws.getColumn(3).width = 16;
          ws.getColumn(4).width = 14; ws.getColumn(5).width = 14;
ws.getColumn(6).width = 15;
         [['Employee Name','FF1F3864'], ['Present / Worked','FF047857'], ['No of Leaves','FFB45309'], ['No of Absent','FFB91C1C'], ['Loc. Not Captured','FF6B7280']].forEach(([hdr, argb], i) => {
            const c = ws.getCell(r, 2 + i);
            c.value = hdr; c.fill = FILL_SUBH; c.border = CBDR;
            c.font = { bold: true, size: 10, color: { argb }, name: 'Calibri' };
            c.alignment = { horizontal: 'center', vertical: 'center' };
          });

          // ── One row per employee ────────────────────────────────────────────
          empList.forEach(({ emp }, idx) => {
            r++; ws.getRow(r).height = 15;
            const rf  = idx % 2 === 0 ? FILL_WHT : FILL_ALT;
            const er  = 5 + idx;

            const cn = ws.getCell(r, 2);
            cn.value = emp.name; cn.fill = rf; cn.border = CBDR;
            cn.font = { size: 10, name: 'Calibri' };
            cn.alignment = { horizontal: 'left', vertical: 'center' };

            const cp = ws.getCell(r, 3);
            cp.value = { formula: `COUNTIF(${fDC}${er}:${lDC}${er},"P")+COUNTIF(${fDC}${er}:${lDC}${er},"OD")` };
            cp.fill = rf; cp.border = CBDR;
            cp.font = { bold: true, size: 10, name: 'Calibri', color: { argb: 'FF047857' } };
            cp.alignment = { horizontal: 'center', vertical: 'center' };
            cp.protection = { locked: true };

            const cl = ws.getCell(r, 4);
            cl.value = { formula: `COUNTIF(${fDC}${er}:${lDC}${er},"L")` };
            cl.fill = rf; cl.border = CBDR;
            cl.font = { bold: true, size: 10, name: 'Calibri', color: { argb: 'FFB45309' } };
            cl.alignment = { horizontal: 'center', vertical: 'center' };
            cl.protection = { locked: true };

           const ca = ws.getCell(r, 5);
            ca.value = { formula: `COUNTIF(${fDC}${er}:${lDC}${er},"A")` };
            ca.fill = rf; ca.border = CBDR;
            ca.font = { bold: true, size: 10, name: 'Calibri', color: { argb: 'FFB91C1C' } };
            ca.alignment = { horizontal: 'center', vertical: 'center' };
            ca.protection = { locked: true };

            const cnl = ws.getCell(r, 6);
            cnl.value = empList[idx].cells.filter(c => c === 'LOC_ERR').length; // computed in JS — not a cell-text COUNTIF
            cnl.fill = rf; cnl.border = CBDR;
            cnl.font = { bold: true, size: 10, name: 'Calibri', color: { argb: 'FF6B7280' } };
            cnl.alignment = { horizontal: 'center', vertical: 'center' };
            cnl.protection = { locked: true };
          });
        }

        outerBorder(ws, SR, 2, r, 6);

        // ── Signatures ────────────────────────────────────────────────────────
        r+=3; ws.getRow(r).height=20;

        if (role === 'employee') {
          // Employee download: Employee sign (left) + Manager sign (right)
          ws.getCell(r,2).value='Employee Sign:';
          ws.getCell(r,2).font={bold:true,size:10,name:'Calibri',color:{argb:'FF1F3864'}};
          mc(ws,r,3,r,6);
          const empSigCell=ws.getCell(r,3);
          empSigCell.value='';
          empSigCell.alignment={horizontal:'center',vertical:'bottom'};
          empSigCell.border={bottom:{style:'medium',color:{argb:'FF1F3864'}}};

          ws.getCell(r,8).value='Reporting Officer Sign:';
          ws.getCell(r,8).font={bold:true,size:15,name:'Calibri',color:{argb:'FF1F3864'}};
          mc(ws,r,12,r,13);
          const mgrSigCell=ws.getCell(r,12);
          mgrSigCell.value=mgrName?`(${mgrName})`:'';
          mgrSigCell.font={italic:true,size:10,name:'Calibri',color:{argb:'FF555555'}};
          mgrSigCell.alignment={horizontal:'center',vertical:'bottom'};
          mgrSigCell.border={bottom:{style:'medium',color:{argb:'FF1F3864'}}};
        }
        // Manager / HR / super_admin / admin: no signature row on exported sheet

        ws.views=[{state:'frozen',xSplit:4,ySplit:4}];
        ws.pageSetup={
          paperSize:9, orientation:'landscape',
          fitToPage:true, fitToWidth:1, fitToHeight:0,
          printTitlesRow:'$1:$4',
          margins:{left:0.2,right:0.2,top:0.4,bottom:0.4,header:0.2,footer:0.2},
        };
      if (role === 'employee') {
  ws.protect('BRP-READONLY',{
    selectLockedCells:true,selectUnlockedCells:true,
    formatCells:false,insertRows:false,insertColumns:false,
    deleteRows:false,deleteColumns:false,sort:false,
  });
}
      };

      if(role==='employee'){
        buildSheet(wb.addWorksheet('My Attendance'),matrix,`${matrix[0]?.emp.name} Summary`,managerName,holCount);
      } else {
        const allName =role==='manager'?'Team Report':'All emp Reports';
        const allTitle=role==='manager'?'Team Summary':'Total Summary';
        buildSheet(wb.addWorksheet(allName),matrix,allTitle,managerName,holCount);
        matrix.forEach(({emp,cells})=>{
          const name=emp.name.replace(/[:\\/?*[\]]/g,'').substring(0,31);
          buildSheet(wb.addWorksheet(name),[{emp,cells}],`${emp.name} Summary`,managerName,holCount);
        });
      }

      const fnamePrefix = matrix.length === 1
        ? `${(matrix[0].emp.name||'').replace(/[^a-zA-Z0-9]+/g,'_').replace(/^_+|_+$/g,'')}_${matrix[0].emp.emp_id||''}_`
        : '';
      res.setHeader('Content-Type','application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
      res.setHeader('Content-Disposition',`attachment; filename="${fnamePrefix}BRP_Attendance_${startDate}_to_${endDate}.xlsx"`);
      res.setHeader('Access-Control-Expose-Headers', 'Content-Disposition');
      await wb.xlsx.write(res);
      return res.end();
    }

    // ══════════════════════════════════════════════════════════════════════════
    //  PDF
    // ══════════════════════════════════════════════════════════════════════════
    if(format==='pdf'){
      const doc=new PDFDoc({size:'A3',layout:'landscape',margins:{top:28,bottom:28,left:28,right:28},autoFirstPage:true});
      res.setHeader('Content-Type','application/pdf');
      res.setHeader('Content-Disposition',`attachment; filename="BRP_Attendance_${startDate}_to_${endDate}.pdf"`);
      res.setHeader('Access-Control-Expose-Headers', 'Content-Disposition');
      doc.pipe(res);

      const PW=doc.page.width,PH=doc.page.height,ML=28;
      const CC=52,CN=105,CD=64,CT=36;
      const dW=Math.max(11,(PW-56-CC-CN-CD-CT)/dates.length);
      const RH=14;
      const xC=ML,xN=ML+CC,xDes=xN+CN,xD=xDes+CD,xT=xD+dates.length*dW,tW=xT+CT-ML;

      const addPage=()=>doc.addPage({size:'A3',layout:'landscape',margins:{top:28,bottom:28,left:28,right:28}});

     const drawHdr=y=>{
  doc.rect(ML,y,tW,20).fill('#FFF').stroke('#AAA');
  doc.fillColor('#000').fontSize(12).font('Helvetica-Bold').text('Attendance details of BRP',ML,y+5,{width:tW,align:'center'});
  doc.rect(ML,y+20,tW,14).fill('#FFF').stroke('#AAA');
  doc.fillColor('#161515').fontSize(8).font('Helvetica').text(rangeTitle,ML,y+23,{width:tW,align:'center'});
  doc.rect(ML,y+34,tW,12).fill('#FFF').stroke('#AAA');
  doc.fillColor('#000').fontSize(7).font('Helvetica-Bold')
     .text('Location: Tripura',ML+4,y+37).text('Project: Block Resource Person',ML+tW/2,y+37);

  const y2=y+46;
  const HRH = multiMonth ? 32 : 24;   // taller header row to fit day-num + weekday (+ month)

  [[xC,CC,'Emp code'],[xN,CN,'Employee Name'],[xDes,CD,'Designation']].forEach(([x,w,l])=>{
    doc.rect(x,y2,w,HRH).fill('#FFF').stroke('#AAA');
    doc.fillColor('#3366FF').fontSize(7).font('Helvetica-Bold')
       .text(l,x+2,y2+(HRH-9)/2,{width:w-4,align:'center'});
  });

  dates.forEach((iso,i)=>{
    const x=xD+i*dW;
    doc.rect(x,y2,dW,HRH).fill('#FFF').stroke('#AAA');
    doc.fillColor('#3366FF').fontSize(6).font('Helvetica-Bold')
       .text(String(dayNum(iso)),x+1,y2+3,{width:dW-2,align:'center'});
    doc.fillColor('#555').fontSize(5).font('Helvetica')
       .text(dayAbbr(iso),x+1,y2+11,{width:dW-2,align:'center'});
    if (multiMonth) {
      doc.fillColor('#888').fontSize(5).font('Helvetica')
         .text(monAbbr(iso),x+1,y2+19,{width:dW-2,align:'center'});
    }
  });

  doc.rect(xT,y2,CT,HRH).fill('#FFF').stroke('#AAA');
  doc.fillColor('#3366FF').fontSize(7).font('Helvetica-Bold')
     .text('Total',xT+2,y2+(HRH-9)/2,{width:CT-4,align:'center'});

  return y2+HRH;
};
      let y=drawHdr(ML);
      matrix.forEach(({emp,cells},idx)=>{
        if(y+RH>PH-60){addPage();y=drawHdr(28);}
        const bg=idx%2===0?'#F9F9F9':'#FFF';
        doc.rect(ML,y,tW,RH).fill(bg).stroke('#CCC');
        doc.fillColor('#000').fontSize(7).font('Helvetica').text(emp.emp_id||'',xC+2,y+3,{width:CC-4,align:'center'});
        doc.font('Helvetica-Bold').text(emp.name,xN+2,y+3,{width:CN-4});
        doc.font('Helvetica').fontSize(6.5).text(emp.role_type||emp.designation||'',xDes+2,y+4,{width:CD-4,align:'center',lineBreak:false,ellipsis:true});
        let pres=0,locErr=0;
        cells.forEach((code,i)=>{
          const x=xD+i*dW;
          const isRed=code==='L'||code==='A';
          const cellBg=isRed?'#FF4444':code==='WO'?'#BDD7EE':code==='H'?'#FFF3CD':bg;
          doc.rect(x,y,dW,RH).fill(cellBg).stroke('#CCC');
            if (code === 'LOC_ERR' && PIN_ERROR_PNG_BUFFER) {
            const iconSize = Math.min(dW-3, RH-2);
            doc.image(PIN_ERROR_PNG_PATH, x+(dW-iconSize)/2, y+(RH-iconSize)/2, {width:iconSize, height:iconSize});
          } else if (code === 'LOC_ERR') {
            doc.fillColor('#DC2626').fontSize(6).font('Helvetica-Bold').text('!',x+1,y+3,{width:dW-2,align:'center'});
          } else
            if(code){
            doc.fillColor(isRed?'#FFFFFF':code==='H'?'#D97706':'#000000').fontSize(6).font('Helvetica-Bold')
               .text(code,x+1,y+3,{width:dW-2,align:'center'});
          }
          if(code==='P'||code==='OD') pres++;
           if(code==='LOC_ERR') locErr++;
        });
        doc.rect(xT,y,CT,RH).fill('#FFF').stroke('#AAA');
        doc.fillColor('#000').fontSize(7).font('Helvetica-Bold').text(String(pres),xT+2,y+3,{width:CT-4,align:'center'});
        y+=RH;
      });

      // Legend
      y+=10; if(y+20>PH-80){addPage();y=40;}
      let lx=ML;
      [{code:'P',label:'Present (assigned location)',red:false},
       {code:'OD',label:'On Duty (other Tripura location)',red:false},
       {code:'L',label:'Leave / LOP',red:true},
       {code:'A',label:'Absent',red:true},
       {code:'WO',label:'Week Off',red:false},
      ].forEach(({code,label,red})=>{
        const bw=14,lw=76;
        doc.rect(lx,y,bw,10).fill(red?'#FF4444':'#FFFFFF').stroke('#999');
        doc.fillColor(red?'#FFFFFF':'#000000').fontSize(6).font('Helvetica-Bold').text(code,lx+1,y+2,{width:bw-2,align:'center'});
        doc.fillColor('#333').fontSize(7).font('Helvetica').text(label,lx+bw+2,y+1,{width:lw});
        lx+=bw+lw+4;
      });
   {
        const bw=14,lw=150;
        if (PIN_ERROR_PNG_BUFFER) {
          doc.image(PIN_ERROR_PNG_PATH, lx, y-1, {width:bw, height:bw*84/64});
        } else {
          doc.rect(lx,y,bw,10).fill('#FFFFFF').stroke('#999');
          doc.fillColor('#DC2626').fontSize(6).font('Helvetica-Bold').text('!',lx+1,y+2,{width:bw-2,align:'center'});
        }
        doc.fillColor('#333').fontSize(7).font('Helvetica').text('Location not captured (GPS/network failed)',lx+bw+2,y+1,{width:lw});
        lx+=bw+lw+4;
      }
      // NEW: same blank-cell explanation as the Excel legend note.
      y+=12;
      doc.fillColor('#64748B').fontSize(6.5).font('Helvetica-Oblique')
         .text('Blank cell (not WO/H) = Leave Applied — awaiting manager approval. Once approved it shows as L.', ML, y, { width: tW });
      y+=18;

      // Summary
      y+=4; if(y+130>PH-60){addPage();y=40;}
      const SW=240,SRH=16,SX=ML; let sy=y;
      const pdfRow=(label,value,type='row')=>{
        if(type==='title'){doc.rect(SX,sy,SW,SRH).fill('#FFF').stroke('#000'); doc.fillColor('#C00000').fontSize(10).font('Helvetica-Bold').text(label,SX,sy+3,{width:SW,align:'center'});}
        else if(type==='sub'){doc.rect(SX,sy,SW,SRH).fill('#E8EDF4').stroke('#000'); doc.fillColor('#1F3864').fontSize(9).font('Helvetica-Bold').text(label,SX,sy+3,{width:SW,align:'center'});}
        else{
          doc.rect(SX,sy,SW*0.72,SRH).fill('#FFF').stroke('#000');
          doc.rect(SX+SW*0.72,sy,SW*0.28,SRH).fill('#FFF').stroke('#000');
          doc.fillColor('#1F3864').fontSize(9).font('Helvetica-Bold').text(label,SX+4,sy+3,{width:SW*0.68});
          if(value!==undefined) doc.text(String(value),SX+SW*0.72,sy+3,{width:SW*0.26,align:'center'});
        }
        sy+=SRH;
      };
      const summaryTitle=role==='employee'?`${matrix[0]?.emp.name} Summary`:role==='manager'?'Team Summary':'Total Summary';
      pdfRow(summaryTitle,undefined,'title');
      pdfRow('No of Total Days',totalDays);
      pdfRow('No of Weekoff (WO)',woCount);
      pdfRow('No of Holidays (H)',holCount);

      if (matrix.length === 1) {
  const cells   = matrix[0].cells;
  const empIdStr = String(matrix[0].emp._id);

  const empLeaveRecs = rawRecs.filter(r =>
    String(r.emp_id) === empIdStr &&
    (r.duty_type === 'Leave' || (r.leave_type && String(r.leave_type).trim()))
  );
  const byType = t => empLeaveRecs.filter(r => String(r.leave_type||'').toLowerCase().includes(t));
  const halfDayRecs   = byType('half');
  const emergencyRecs = byType('emergency');
  const casualRecs    = byType('casual');
  const pendingRecs   = empLeaveRecs.filter(r => (r.leave_status || r.status || 'Pending') === 'Pending');
  const effectiveLeaves = empLeaveRecs.reduce((sum, r) => {
    const ls = r.leave_status || r.status || 'Pending';
    if (ls === 'Pending') return sum;
    const isHalf = String(r.leave_type||'').toLowerCase().includes('half');
    const hasCheckin = r.checkin_time || r.checkinTime;
    if (ls === 'Approved') return sum + (isHalf ? 0.5 : 1); // approved leave always counts (matches toCode's unconditional 'L')
    if (ls === 'Rejected') return hasCheckin ? sum : sum + (isHalf ? 0.5 : 1);
    return sum;
  }, 0);

  pdfRow('No of Present / worked (P+OD)', cells.filter(c => c==='P'||c==='OD').length);
  pdfRow('No of Leaves (L)',               cells.filter(c => c==='L').length);
  pdfRow('No of Half Day Leaves (each = 0.5 day)', halfDayRecs.length);
  pdfRow('No of Emergency Leaves',                 emergencyRecs.length);
  pdfRow('No of Casual Leaves',                    casualRecs.length);
  pdfRow('Total Effective Leaves',                 effectiveLeaves);
  pdfRow('No of Absent (A)',               cells.filter(c => c==='A').length);
  pdfRow('No of Leave Applied / Pending (LA)',      pendingRecs.length);
  pdfRow('No of Location Not Captured',    cells.filter(c => c==='LOC_ERR').length);
} else {
        sy++;
        const TW = SW;
        const C0 = TW * 0.46;
        const C1 = TW * 0.18;
        const C2 = TW * 0.18;
        const C3 = TW * 0.18;

        doc.rect(SX,        sy, C0, SRH).fill('#E8EDF4').stroke('#000');
        doc.rect(SX+C0,     sy, C1, SRH).fill('#D1FAE5').stroke('#000');
        doc.rect(SX+C0+C1,  sy, C2, SRH).fill('#FEF3C7').stroke('#000');
        doc.rect(SX+C0+C1+C2, sy, C3, SRH).fill('#FEE2E2').stroke('#000');

        doc.fillColor('#1F3864').fontSize(8).font('Helvetica-Bold').text('Employee',   SX+4,    sy+4, {width:C0-8});
        doc.fillColor('#047857').fontSize(8).font('Helvetica-Bold').text('Present',    SX+C0,   sy+4, {width:C1,align:'center'});
        doc.fillColor('#B45309').fontSize(8).font('Helvetica-Bold').text('Leaves',     SX+C0+C1,sy+4, {width:C2,align:'center'});
        doc.fillColor('#B91C1C').fontSize(8).font('Helvetica-Bold').text('Absent',     SX+C0+C1+C2,sy+4,{width:C3,align:'center'});
        sy += SRH;

        matrix.forEach(({ emp, cells }, idx) => {
          const bg = idx % 2 === 0 ? '#FFFFFF' : '#F7F7F7';
          doc.rect(SX,          sy, C0, SRH).fill(bg).stroke('#CCCCCC');
          doc.rect(SX+C0,       sy, C1, SRH).fill(bg).stroke('#CCCCCC');
          doc.rect(SX+C0+C1,    sy, C2, SRH).fill(bg).stroke('#CCCCCC');
          doc.rect(SX+C0+C1+C2, sy, C3, SRH).fill(bg).stroke('#CCCCCC');

          const pres = cells.filter(c => c==='P'||c==='OD').length;
          const lv   = cells.filter(c => c==='L').length;
          const abs  = cells.filter(c => c==='A').length;
 const nlc  = cells.filter(c => c==='LOC_ERR').length;
          doc.fillColor('#1F3864').fontSize(8.5).font('Helvetica-Bold').text(emp.name,     SX+4,   sy+3,{width:C0-8,lineBreak:false,ellipsis:true});
          doc.fillColor('#047857').fontSize(9  ).font('Helvetica-Bold').text(String(pres), SX+C0,  sy+3,{width:C1,align:'center'});
          doc.fillColor('#B45309').fontSize(9  ).font('Helvetica-Bold').text(String(lv),   SX+C0+C1,sy+3,{width:C2,align:'center'});
          doc.fillColor('#B91C1C').fontSize(9  ).font('Helvetica-Bold').text(String(abs),  SX+C0+C1+C2,sy+3,{width:C3,align:'center'});
          sy += SRH;
        });
      }

      // Signatures (employee download only)
      sy+=24; if(sy+30>PH-28){addPage();sy=40;}
      const sigLineW=140;
if (role === 'employee') {
  // Employee Sign
  doc.fillColor('#1F3864').fontSize(12).font('Helvetica-Bold').text('Employee Sign:', ML, sy);
  doc.moveTo(ML + 110, sy + 12).lineTo(ML + 110 + sigLineW, sy + 12).stroke('#999');

  // Reporting Officer block — CSS matched to reference layout
  const roX = ML + 110 + sigLineW + 80;
  doc.fillColor('#1F3864').fontSize(12).font('Helvetica-Bold').text('Reporting Officer:', roX, sy);

  const lineGap = 30;
  let ry = sy + lineGap;

  // Name/Designation — thin grey line, value (if known) sits above the line
  doc.fillColor('#3B6EA5').fontSize(9).font('Helvetica').text('Name/Designation:', roX, ry);
  if (managerName) {
    doc.fillColor('#333').fontSize(10).font('Helvetica-Oblique')
       .text(managerName, roX + 100, ry - 9, { width: sigLineW });
  }
  doc.moveTo(roX + 100, ry + 9).lineTo(roX + 100 + sigLineW, ry + 9).stroke('#999');

  ry += lineGap + 10;
  doc.fillColor('#3B6EA5').fontSize(9).font('Helvetica').text('Signature & Stamp:', roX, ry);
  doc.moveTo(roX + 100, ry + 9).lineTo(roX + 100 + sigLineW, ry + 9).stroke('#1F3864');

  ry += lineGap + 10;
  doc.fillColor('#3B6EA5').fontSize(9).font('Helvetica').text('Date:', roX, ry);
  doc.moveTo(roX + 100, ry + 9).lineTo(roX + 100 + sigLineW * 0.55, ry + 9).stroke('#999');
}

      doc.end();
      return;
    }

    res.status(400).json({success:false,message:'format must be excel or pdf'});
  } catch(err){
    console.error('[ReportsExport]',err);
    res.status(500).json({success:false,message:'Export failed',error:err.message});
  }
});

// ══════════════════════════════════════════════════════════════════════════════
//  GET /api/reports/leave-export
// ══════════════════════════════════════════════════════════════════════════════
router.get('/leave-export',
  authenticate,
  authorize('super_admin', 'admin', 'hr', 'manager', 'employee'),
  async (req, res) => {
  try {
    const { format = 'excel', status, empId } = req.query;
    const role = req.user.role;
    let { startDate, endDate } = req.query;

    if (!startDate || !endDate)
      return res.status(400).json({ success: false, message: 'startDate and endDate are required' });

    // NO cap to yesterday for leave reports — leaves are complete records
    if (startDate > endDate)
      return res.status(400).json({ success: false, message: 'startDate must be before or equal to endDate' });

    // ── Employee scope ─────────────────────────────────────────────────────────
    let employees = [];

    if (role === 'employee') {
      const me = await User.findById(req.user.id).select('_id name emp_id').lean();
      if (me) employees = [me];

    } else if (empId && String(empId).trim() !== '') {
      const specific = await User.findById(toObjId(empId)).select('_id name emp_id').lean();
      if (specific) employees = [specific];
      else return res.status(404).json({ success: false, message: 'Selected employee not found' });

    } else if (role === 'manager') {
      employees = await User.find({ manager_id: toObjId(req.user.id), is_active: { $ne: false } })
        .select('_id name emp_id').sort({ emp_id: 1 }).lean();

    } else {
      employees = await User.find({ role: 'employee', is_active: { $ne: false } })
        .select('_id name emp_id').sort({ emp_id: 1 }).lean();
    }

    if (!employees.length)
      return res.status(404).json({ success: false, message: 'No employees found' });

    // ── Fetch records ──────────────────────────────────────────────────────────
       // ── Fetch records ──────────────────────────────────────────────────────────
    const allRecs = await AttendanceRecord.find({
      date:   { $gte: startDate, $lte: endDate },
      emp_id: { $in: employees.map(e => e._id) },
    }).sort({ date: 1 }).lean();

    const todayISO = todayIST();

    const isMissedCheckoutRec = r =>
      r.is_missed_checkout === true ||
      (r.status === 'Draft' && r.checkin_time && !r.checkout_time && r.date < todayISO);

    const isLeaveRec = r =>
      r.duty_type === 'Leave' || (r.leave_type && String(r.leave_type).trim() !== '');

    const isMissedReport = status === 'Missed Check-out';

    const combinedRecs = allRecs.filter(r => isLeaveRec(r) || isMissedCheckoutRec(r));

    let filtered;
    if (isMissedReport) {
      filtered = combinedRecs.filter(isMissedCheckoutRec);
    } else if (status && status !== 'All') {
      filtered = combinedRecs.filter(r =>
        isMissedCheckoutRec(r) ? r.status === status : r.leave_status === status
      );
    } else {
      filtered = combinedRecs.filter(isLeaveRec); // leave-only for the default/"All" leave view
    }

    const empMap = {};
    for (const e of employees) empMap[String(e._id)] = e;

    const overrideLabel = r => {
      if (!r.hr_override) return '';
      const who = r.overridden_by === 'super_admin' ? 'Super Admin' : r.overridden_by === 'hr' ? 'HR' : '';
      const remark = (r.override_remark || r.hr_remark || '').replace(/^\[(HR|Super Admin) Override\]\s*/i, '').trim();
      return who ? `${who}${remark ? `: ${remark}` : ''}` : remark;
    };

    const rows = isMissedReport
  ? await Promise.all(filtered.map(async r => ({
      empCode:         empMap[String(r.emp_id)]?.emp_id || '',
      empName:         empMap[String(r.emp_id)]?.name   || '',
      date:            r.date || '',
      checkinTime:     r.checkin_time || '',
      locationCheckin: await buildLocationText(r.location_address, r.latitude ?? r.checkin_lat, r.longitude ?? r.checkin_lng),
      managerAction:   r.status || 'Pending',
      managerRemark:   (r.manager_remark || r.checkout_remarks || '').replace(/^\[(HR|Super Admin) Override\]\s*/i, '').trim(),
      override:        overrideLabel(r),
    })))
      : filtered.map(r => {
          const startD   = r.date || '';
          const endD     = r.end_date || startD;
          const dayCount = (startD && endD && endD !== startD)
            ? Math.round((new Date(endD) - new Date(startD)) / 86400000) + 1
            : 1;
          return {
            empCode:       empMap[String(r.emp_id)]?.emp_id || '',
            empName:       empMap[String(r.emp_id)]?.name   || '',
            startDate:     startD,
            endDate:       endD !== startD ? endD : '',
            days:          String(dayCount),
            leaveType:     r.leave_type     || '',
            status:        r.leave_status   || r.status || '',
            reason:        r.leave_reason   || '',
            managerRemark: r.manager_remark || '',
            hrOverride:    r.hr_override    ? 'Yes' : 'No',
            hrRemark:      r.hr_remark      || '',
          };
        });

    const sd = new Date(startDate + 'T00:00:00+05:30');
    const ed = new Date(endDate   + 'T00:00:00+05:30');
    const rangeLabel =
      `${ordinal(sd.getDate())} ${sd.toLocaleDateString('en-IN', { timeZone: IST, month: 'short' })} ${sd.getFullYear()}` +
      ` To ` +
      `${ordinal(ed.getDate())} ${ed.toLocaleDateString('en-IN', { timeZone: IST, month: 'long' })} ${ed.getFullYear()}`;

    const reportLabel = isMissedReport ? 'Missed Check-out Report' : 'Leave Report';
    const reportTitle = employees.length === 1
      ? `${reportLabel} – ${employees[0].name} (${employees[0].emp_id || '—'})`
      : `${reportLabel} – BRP (Block Resource Person)`;

    const statusOf = r => isMissedReport ? r.managerAction : r.status;
    const approved = rows.filter(r => statusOf(r) === 'Approved').length;
    const rejected = rows.filter(r => statusOf(r) === 'Rejected').length;
    const pending  = rows.filter(r => statusOf(r) === 'Pending').length;

    // ══════════════════════════════════════════════════════════════════════════
    //  EXCEL
    // ══════════════════════════════════════════════════════════════════════════
    if (format === 'excel') {
      const wb = new ExcelJS.Workbook(); wb.creator = 'RAMP AMS';
      const ws = wb.addWorksheet(isMissedReport ? 'Missed Checkout Report' : 'Leave Report');

      const FILL_HDR     = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FF1F3864' } };
      const FILL_SUB     = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FFE8EDF4' } };
      const FILL_EVEN    = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FFFFFFFF' } };
      const FILL_ODD     = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FFF7F7F7' } };
      const FILL_APPROVE = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FFD1FAE5' } };
      const FILL_REJECT  = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FFFEE2E2' } };
      const FILL_PENDING = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FFFFF9C4' } };
      const CBDR = {
        top:    { style: 'thin', color: { argb: 'FFCCCCCC' } },
        bottom: { style: 'thin', color: { argb: 'FFCCCCCC' } },
        left:   { style: 'thin', color: { argb: 'FFCCCCCC' } },
        right:  { style: 'thin', color: { argb: 'FFCCCCCC' } },
      };

      const COLS = isMissedReport ? [
        { key: 'empCode',         header: 'Emp Code',                  width: 12 },
        { key: 'empName',         header: 'Emp Name',                  width: 22 },
        { key: 'date',            header: 'Date',                      width: 14 },
        { key: 'checkinTime',     header: 'Check-in Time',             width: 14, group: true },
        { key: 'locationCheckin', header: 'Location Check-in',         width: 42, group: true },
        { key: 'managerAction',   header: 'Manager Action',            width: 16 },
        { key: 'managerRemark',   header: 'Manager Remark',            width: 28 },
        { key: 'override',        header: 'Override (Name & Remark)',  width: 34 },
      ] : [
        { key: 'empCode',       header: 'Emp Code',      width: 12 },
        { key: 'empName',       header: 'Employee Name', width: 22 },
        { key: 'startDate',     header: 'From Date',     width: 14 },
        { key: 'endDate',       header: 'To Date',       width: 14 },
        { key: 'days',          header: 'Days',          width:  7 },
        { key: 'leaveType',     header: 'Leave Type',    width: 18 },
        { key: 'status',        header: 'Status',        width: 14 },
        { key: 'reason',        header: 'Reason',        width: 32 },
        { key: 'managerRemark', header: 'Manager Remark',width: 28 },
        { key: 'hrOverride',    header: 'HR Override',   width: 13 },
        { key: 'hrRemark',      header: 'HR Remark',     width: 28 },
      ];
      const NC = COLS.length;

      ws.mergeCells(1, 1, 1, NC);
      Object.assign(ws.getCell(1, 1), {
        value: reportTitle,
        font:  { bold: true, size: 14, color: { argb: 'FFFFFFFF' }, name: 'Calibri' },
        fill:  FILL_HDR,
        alignment: { horizontal: 'center', vertical: 'center' },
      });
      ws.getRow(1).height = 26;

      ws.mergeCells(2, 1, 2, NC);
      Object.assign(ws.getCell(2, 1), {
        value: `Period: ${rangeLabel}`,
        font:  { bold: true, size: 11, color: { argb: 'FF1F3864' }, name: 'Calibri' },
        fill:  FILL_SUB,
        alignment: { horizontal: 'center', vertical: 'center' },
      });
      ws.getRow(2).height = 18;

      ws.mergeCells(3, 1, 3, NC);
      Object.assign(ws.getCell(3, 1), {
        value: `Total: ${rows.length}   |   Approved: ${approved}   |   Rejected: ${rejected}   |   Pending: ${pending}`,
        font:  { size: 10, italic: true, color: { argb: 'FF444444' }, name: 'Calibri' },
        fill:  FILL_SUB,
        alignment: { horizontal: 'center', vertical: 'center' },
      });
      ws.getRow(3).height = 15;

      let headerRow = 4;

      if (isMissedReport) {
        ws.getRow(4).height = 16;
        ws.getRow(5).height = 16;

        const groupIdxs = COLS.reduce((arr, c, i) => c.group ? [...arr, i + 1] : arr, []);

        COLS.forEach((col, i) => {
          const colIdx = i + 1;
          ws.getColumn(colIdx).width = col.width;
          if (!col.group) {
            ws.mergeCells(4, colIdx, 5, colIdx);
            const c = ws.getCell(4, colIdx);
            c.value = col.header;
            c.font  = { bold: true, size: 10, color: { argb: 'FFFFFFFF' }, name: 'Calibri' };
            c.fill  = FILL_HDR;
            c.border = CBDR;
            c.alignment = { horizontal: 'center', vertical: 'center' };
            ws.getCell(5, colIdx).border = CBDR;
          }
        });

        if (groupIdxs.length) {
          const gStart = groupIdxs[0], gEnd = groupIdxs[groupIdxs.length - 1];
          ws.mergeCells(4, gStart, 4, gEnd);
          Object.assign(ws.getCell(4, gStart), {
            value: 'Missed Check-out ',
            font:  { bold: true, size: 10, color: { argb: 'FFFFFFFF' }, name: 'Calibri' },
            fill:  FILL_HDR,
            border: CBDR,
            alignment: { horizontal: 'center', vertical: 'center' },
          });
          groupIdxs.forEach(colIdx => {
            const col = COLS[colIdx - 1];
            const c = ws.getCell(5, colIdx);
            c.value = col.header;
            c.font  = { bold: true, size: 9, color: { argb: 'FF1F3864' }, name: 'Calibri' };
            c.fill  = FILL_SUB;
            c.border = CBDR;
            c.alignment = { horizontal: 'center', vertical: 'center' };
          });
        }
        headerRow = 5;
      } else {
        ws.getRow(4).height = 18;
        COLS.forEach((col, i) => {
          ws.getColumn(i + 1).width = col.width;
          const c = ws.getCell(4, i + 1);
          c.value = col.header;
          c.font  = { bold: true, size: 10, color: { argb: 'FFFFFFFF' }, name: 'Calibri' };
          c.fill  = FILL_HDR;
          c.border = CBDR;
          c.alignment = { horizontal: 'center', vertical: 'center' };
        });
      }

      const dataStart = headerRow + 1;

      if (rows.length === 0) {
        ws.mergeCells(dataStart, 1, dataStart, NC);
        Object.assign(ws.getCell(dataStart, 1), {
          value: isMissedReport
            ? 'No missed check-out records found for the selected period and filters.'
            : 'No leave records found for the selected period and filters.',
          font: { italic: true, size: 10, color: { argb: 'FF888888' } },
          alignment: { horizontal: 'center', vertical: 'center' },
        });
        ws.getRow(dataStart).height = 18;
      } else {
        rows.forEach((row, idx) => {
          const rowN = dataStart + idx;
          ws.getRow(rowN).height = 15;
          const sv = statusOf(row);
          let rowFill = idx % 2 === 0 ? FILL_EVEN : FILL_ODD;
          if      (sv === 'Approved') rowFill = FILL_APPROVE;
          else if (sv === 'Rejected') rowFill = FILL_REJECT;
          else if (sv === 'Pending')  rowFill = FILL_PENDING;

          const centerKeys = isMissedReport
            ? ['empCode', 'date', 'checkinTime', 'managerAction']
            : ['empCode', 'status', 'hrOverride', 'days', 'startDate', 'endDate'];
          const wrapKeys = isMissedReport
            ? ['locationCheckin', 'managerRemark', 'override']
            : ['reason', 'managerRemark', 'hrRemark'];

          COLS.forEach((col, i) => {
            const c = ws.getCell(rowN, i + 1);
            c.value  = row[col.key] || '';
            c.fill   = rowFill;
            c.border = CBDR;
            c.font   = { size: 9, name: 'Calibri' };
            c.alignment = {
              horizontal: centerKeys.includes(col.key) ? 'center' : 'left',
              vertical:   'center',
              wrapText:   wrapKeys.includes(col.key),
            };
          });

          const statusColIdx = isMissedReport
            ? COLS.findIndex(c => c.key === 'managerAction') + 1
            : COLS.findIndex(c => c.key === 'status') + 1;
          if (statusColIdx > 0) {
            const sc = ws.getCell(rowN, statusColIdx);
            const statusColor = sv === 'Approved' ? 'FF047857' : sv === 'Rejected' ? 'FFB91C1C' : 'FFB45309';
            sc.font = { bold: true, size: 9, name: 'Calibri', color: { argb: statusColor } };
          }
        });
      }

      ws.views = [{ state: 'frozen', xSplit: 2, ySplit: headerRow }];
      ws.autoFilter = { from: { row: headerRow, column: 1 }, to: { row: headerRow, column: NC } };
      ws.pageSetup = {
        paperSize: 9, orientation: 'landscape',
        fitToPage: true, fitToWidth: 1, fitToHeight: 0,
        printTitlesRow: `$1:$${headerRow}`,
        margins: { left: 0.3, right: 0.3, top: 0.4, bottom: 0.4, header: 0.2, footer: 0.2 },
      };

      const fname = isMissedReport
        ? `Missed_Checkout_Report_${startDate}_to_${endDate}.xlsx`
        : `Leave_Report_${startDate}_to_${endDate}.xlsx`;

      res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
      res.setHeader('Content-Disposition', `attachment; filename="${fname}"`);
      res.setHeader('Access-Control-Expose-Headers', 'Content-Disposition');
      await wb.xlsx.write(res);
      return res.end();
    }

    // ══════════════════════════════════════════════════════════════════════════
    //  PDF
    // ══════════════════════════════════════════════════════════════════════════
    if (format === 'pdf') {
      const doc = new PDFDoc({
        size: 'A3', layout: 'landscape',
        margins: { top: 28, bottom: 28, left: 28, right: 28 },
        autoFirstPage: true,
      });
      const fname = isMissedReport
        ? `Missed_Checkout_Report_${startDate}_to_${endDate}.pdf`
        : `Leave_Report_${startDate}_to_${endDate}.pdf`;
      res.setHeader('Content-Type', 'application/pdf');
      res.setHeader('Content-Disposition', `attachment; filename="${fname}"`);
      res.setHeader('Access-Control-Expose-Headers', 'Content-Disposition');
      doc.pipe(res);

      const ML      = 28;
      const usableW = doc.page.width - ML * 2;

      const colDefs = isMissedReport ? [
        { key: 'empCode',         header: 'Emp Code',                 w: 48  },
        { key: 'empName',         header: 'Emp Name',                 w: 100 },
        { key: 'date',            header: 'Date',                     w: 60  },
        { key: 'checkinTime',     header: 'Check-in Time',            w: 70,  group: true },
        { key: 'locationCheckin', header: 'Location Check-in',        w: 440, group: true },
        { key: 'managerAction',   header: 'Manager Action',           w: 75  },
        { key: 'managerRemark',   header: 'Manager Remark',           w: 140 },
        { key: 'override',        header: 'Override (Name & Remark)', w: 160 },
      ] : [
        { key: 'empCode',       header: 'Emp Code',       w: 48  },
        { key: 'empName',       header: 'Employee Name',  w: 105 },
        { key: 'startDate',     header: 'From Date',      w: 58  },
        { key: 'endDate',       header: 'To Date',        w: 58  },
        { key: 'days',          header: 'Days',           w: 28  },
        { key: 'leaveType',     header: 'Leave Type',     w: 75  },
        { key: 'status',        header: 'Status',         w: 62  },
        { key: 'reason',        header: 'Reason',         w: 130 },
        { key: 'managerRemark', header: 'Manager Remark', w: 120 },
        { key: 'hrOverride',    header: 'HR Override',    w: 48  },
        { key: 'hrRemark',      header: 'HR Remark',      w: 105 },
      ];

      const totalW = colDefs.reduce((a, c) => a + c.w, 0);
      const cw = colDefs.map(c => (c.w / totalW) * usableW);
      const RH = 14, HRH = 16, GROUP_RH = 14;
      let y = ML;

      const drawPageHeader = (yy) => {
        doc.rect(ML, yy, usableW, 20).fill('#1F3864');
        doc.fillColor('#FFFFFF').fontSize(11).font('Helvetica-Bold')
           .text(reportTitle, ML, yy + 5, { width: usableW, align: 'center' });
        yy += 20;
        doc.rect(ML, yy, usableW, 13).fill('#E8EDF4').stroke('#CCCCCC');
        doc.fillColor('#1F3864').fontSize(8).font('Helvetica')
           .text(
             `Period: ${rangeLabel}   |   Total: ${rows.length}   Approved: ${approved}   Rejected: ${rejected}   Pending: ${pending}`,
             ML + 4, yy + 3, { width: usableW - 8, align: 'center' }
           );
        yy += 13;

        if (isMissedReport) {
          doc.rect(ML, yy, usableW, GROUP_RH).fill('#1F3864').stroke('#AAAAAA');
          let gx = ML, groupStartX = null, groupW = 0;
          colDefs.forEach((c, i) => {
            if (c.group) { if (groupStartX === null) groupStartX = gx; groupW += cw[i]; }
            gx += cw[i];
          });
          if (groupStartX !== null) {
            doc.fillColor('#FFFFFF').fontSize(7.5).font('Helvetica-Bold')
               .text('Missed Check-out (Date Range)', groupStartX, yy + 3, { width: groupW, align: 'center' });
          }
          yy += GROUP_RH;
        }

        let cx = ML;
        colDefs.forEach((c, i) => {
          doc.rect(cx, yy, cw[i], HRH).fill('#1F3864').stroke('#AAAAAA');
          doc.fillColor('#FFFFFF').fontSize(6.5).font('Helvetica-Bold')
             .text(c.header, cx + 2, yy + 4, { width: cw[i] - 4, align: 'center' });
          cx += cw[i];
        });
        return yy + HRH;
      };

      y = drawPageHeader(y);

      if (rows.length === 0) {
        doc.rect(ML, y, usableW, RH).fill('#FFFFFF').stroke('#CCCCCC');
        doc.fillColor('#888888').fontSize(8).font('Helvetica-Oblique')
           .text(
             isMissedReport
               ? 'No missed check-out records found for the selected period and filters.'
               : 'No leave records found for the selected period and filters.',
             ML, y + 3, { width: usableW, align: 'center' }
           );
      } else {
        const statusKey = isMissedReport ? 'managerAction' : 'status';
        const centerKeys = isMissedReport
          ? ['empCode', 'date', 'checkinTime', 'managerAction']
          : ['empCode', 'status', 'hrOverride', 'days', 'startDate', 'endDate'];

        rows.forEach((row, idx) => {
          if (y + RH > doc.page.height - 40) {
            doc.addPage({ size: 'A3', layout: 'landscape', margins: { top: 28, bottom: 28, left: 28, right: 28 } });
            y = drawPageHeader(28);
          }
          const sv = row[statusKey];
          const bg =
            sv === 'Approved' ? '#D1FAE5' :
            sv === 'Rejected' ? '#FEE2E2' :
            sv === 'Pending'  ? '#FFF9C4' :
            (idx % 2 === 0 ? '#FFFFFF' : '#F9F9F9');

          doc.rect(ML, y, usableW, RH).fill(bg).stroke('#DDDDDD');
          let cx = ML;
          colDefs.forEach((c, i) => {
            const val = String(row[c.key] || '');
            const isCenter = centerKeys.includes(c.key);
            const textColor = c.key === statusKey
              ? (sv === 'Approved' ? '#047857' : sv === 'Rejected' ? '#B91C1C' : '#B45309')
              : '#000000';
            doc.rect(cx, y, cw[i], RH).stroke('#DDDDDD');
            doc.fillColor(textColor).fontSize(6)
               .font(c.key === statusKey ? 'Helvetica-Bold' : 'Helvetica')
               .text(val, cx + 2, y + 3, { width: cw[i] - 4, align: isCenter ? 'center' : 'left', lineBreak: false, ellipsis: true });
            cx += cw[i];
          });
          y += RH;
        });
      }

      doc.end();
      return;
    }

    res.status(400).json({ success: false, message: 'format must be excel or pdf' });
  } catch (err) {
    console.error('[LeaveExport]', err);
    res.status(500).json({ success: false, message: 'Leave export failed', error: err.message });
  }
});

// ── dashboard-stats ───────────────────────────────────────────────────────────
router.get('/dashboard-stats', authenticate, async (req,res)=>{
  try{
    const today=new Date().toISOString().split('T')[0];
    const thisMonth=today.substring(0,7);
    const empFilter={};
    if(req.user.role==='employee')     empFilter.emp_id    =toObjId(req.user.id);
    else if(req.user.role==='manager') empFilter.manager_id=toObjId(req.user.id);
    const monthStart=`${thisMonth}-01`;
    const [year,month]=thisMonth.split('-').map(Number);
    const nextMonth=month===12?`${year+1}-01-01`:`${year}-${String(month+1).padStart(2,'0')}-01`;
    const monthlyResult=await AttendanceRecord.aggregate([
      {$match:{date:{$gte:monthStart,$lt:nextMonth},...empFilter}},
      {$group:{_id:null,total:{$sum:1},approved:{$sum:{$cond:[{$eq:['$status','Approved']},1,0]}},pending:{$sum:{$cond:[{$eq:['$status','Pending']},1,0]}},rejected:{$sum:{$cond:[{$eq:['$status','Rejected']},1,0]}},on_duty:{$sum:{$cond:[{$eq:['$duty_type','On Duty']},1,0]}}}},
      {$project:{_id:0}},
    ]);
    const monthly=monthlyResult[0]||{total:0,approved:0,pending:0,rejected:0,on_duty:0};
    const sevenDaysAgo=new Date(); sevenDaysAgo.setDate(sevenDaysAgo.getDate()-7);
    const trend=await AttendanceRecord.aggregate([
      {$match:{date:{$gte:sevenDaysAgo.toISOString().split('T')[0]},...empFilter}},
      {$group:{_id:'$date',count:{$sum:1},approved:{$sum:{$cond:[{$eq:['$status','Approved']},1,0]}}}},
      {$project:{_id:0,date:'$_id',count:1,approved:1}},
      {$sort:{date:1}},
    ]);
    res.json({success:true,data:{monthly,trend}});
  }catch(err){
    res.status(500).json({success:false,message:'Server error',error:err.message});
  }
});
// ══════════════════════════════════════════════════════════════════════════════
//  GET /api/reports/daily-log-export
//  Single-employee daily log: Date | Check-In | Check-Out | Total Time | Duty Type | Leave Type
//  status: 'All' | 'Today Check-in' | 'Pending' | 'Approved' | 'Rejected'  (mirrors the queue tabs)
//
//  Check-In colour rule:  before 10:00 AM → green (good) | at/after 10:00 AM → red (late)
//  Check-Out colour rule: before 4:00 PM  → red (early)  | at/after 5:30 PM  → green (good)
//                         between 4:00–5:30 PM → neutral (no fill)
// ══════════════════════════════════════════════════════════════════════════════
router.get('/daily-log-export',
  authenticate,
  authorize('super_admin','admin','hr','manager','employee'),
  async (req, res) => {
  try {
    const { format='excel', empId, status='All' } = req.query;
    let { startDate, endDate } = req.query;
    const role = req.user.role;

    const targetEmpId = role === 'employee' ? req.user.id : empId;
    if (!targetEmpId)
      return res.status(400).json({success:false,message:'empId is required'});

    const emp = await User.findById(toObjId(targetEmpId))
      .select('_id name emp_id assigned_block assigned_district role_type designation')
      .lean();
    if (!emp) return res.status(404).json({success:false,message:'Employee not found'});

    // "Today Check-in" tab forces the date range to today
    if (status === 'Today Check-in') startDate = endDate = todayIST();
    if (!startDate || !endDate)
      return res.status(400).json({success:false,message:'startDate and endDate are required'});

    const recFilter = { date:{$gte:startDate,$lte:endDate}, emp_id: emp._id };
    if (status && !['All','Today Check-in'].includes(status)) recFilter.status = status;

    let recs = await AttendanceRecord.find(recFilter).sort({date:1}).lean();
    if (status === 'Today Check-in') {
      recs = recs.filter(r =>
        r.checkin_time || r.checkinTime || r.check_in_time || r.checkIn
      );
    }

    // ── Safe time parsing: handles ISO datetime, plain "HH:mm", epoch, or Date ──
    const parseDateTime = (dateStr, timeVal) => {
      if (!timeVal) return null;
      if (timeVal instanceof Date) return isNaN(timeVal) ? null : timeVal;
      if (typeof timeVal === 'number') {
        const d = new Date(timeVal);
        return isNaN(d) ? null : d;
      }
      if (typeof timeVal === 'string') {
        // Full ISO date/datetime string
        if (/^\d{4}-\d{2}-\d{2}/.test(timeVal) || timeVal.includes('T')) {
          const d = new Date(timeVal);
          return isNaN(d) ? null : d;
        }
        // Plain "HH:mm" or "HH:mm:ss" — combine with the record's own date
        const m = timeVal.match(/^(\d{1,2}):(\d{2})(:(\d{2}))?/);
        if (m && dateStr) {
          const d = new Date(`${dateStr}T${m[1].padStart(2,'0')}:${m[2]}:${m[4]||'00'}+05:30`);
          return isNaN(d) ? null : d;
        }
      }
      return null;
    };

    const fmtHM   = mins => `${Math.floor(mins/60)}h ${mins%60}m`;
    const timeStr = d => d ? d.toLocaleTimeString('en-IN',{timeZone:IST,hour:'2-digit',minute:'2-digit',hour12:false}) : '';

    // Threshold buckets — matches the legend (Check-In: 10 AM · Check-Out: 4 PM / 5:30 PM)
    const CHECKIN_CUTOFF = 10*60;         // 10:00 AM in minutes
    const CHECKOUT_EARLY = 16*60;         // 4:00 PM
    const CHECKOUT_FULL  = 17*60 + 30;    // 5:30 PM
    const minsOfDay = d => d.getHours()*60 + d.getMinutes();

    const checkinStatus = d => {
      if (!d) return null;
      return minsOfDay(d) < CHECKIN_CUTOFF ? 'good' : 'late'; // green / red
    };
    const checkoutStatus = d => {
      if (!d) return null;
      const m = minsOfDay(d);
      if (m < CHECKOUT_EARLY) return 'early';   // red
      if (m >= CHECKOUT_FULL) return 'good';    // green
      return null;                              // neutral, between 4–5:30
    };

    const rows = recs.map(r => {
      const ciRaw = r.checkin_time ?? r.checkinTime ?? r.check_in_time ?? r.checkIn;
      const coRaw = r.checkout_time ?? r.checkoutTime ?? r.check_out_time ?? r.checkOut;
      const ci = parseDateTime(r.date, ciRaw);
      const co = parseDateTime(r.date, coRaw);

      let total = '';
      let coDisplay = '';
      if (ci && co) {
        const mins = Math.round((co - ci) / 60000);
        total = mins > 0 ? fmtHM(mins) : '';
        coDisplay = timeStr(co);
      } else if (ci && !co) {
        coDisplay = 'Missed';
      }

      return {
        date: r.date,
        checkin: ci ? timeStr(ci) : '',
        checkout: coDisplay,
        total,
        dutyType: r.duty_type || '',
        leaveType: r.leave_type || '',
        missedCheckout: !!(ci && !co),
        checkinFlag:  checkinStatus(ci),
        checkoutFlag: co ? checkoutStatus(co) : null,
      };
    });

    const workingDays    = rows.filter(r => r.dutyType==='Office Duty' || r.dutyType==='On Duty').length;
    const holidays        = recs.filter(r => (r.duty_type||'').toLowerCase()==='holiday').length;
    const leaves            = recs.filter(r => r.duty_type==='Leave' || (r.leave_type && String(r.leave_type).trim())).length;
    const missedCheckout  = rows.filter(r => r.missedCheckout).length;
    const absent            = recs.filter(r => (r.duty_type||'').toLowerCase()==='absent' ||
                              (r.status==='Rejected' && !(r.checkin_time||r.checkinTime||r.check_in_time||r.checkIn))).length;
    const totalDays         = rows.length;
    const approved           = recs.filter(r => (r.leave_status||r.status)==='Approved').length;
    const pending             = recs.filter(r => (r.leave_status||r.status)==='Pending').length;
    const rejected             = recs.filter(r => (r.leave_status||r.status)==='Rejected').length;

    const headerLine = [emp.emp_id, emp.name, emp.assigned_district, emp.assigned_block]
      .filter(Boolean).join('  |  ');

    // ── Filename helper — used by both formats ────────────────────────────
    const sanitize = s => String(s||'').trim().replace(/[^a-zA-Z0-9]+/g,'_').replace(/^_+|_+$/g,'');
    const rangePart = status === 'Today Check-in' ? sanitize(startDate) : `${startDate}_to_${endDate}`;
    const fnameBase = `${sanitize(emp.name)}${emp.emp_id?'_'+sanitize(emp.emp_id):''}_${sanitize(status)}_${rangePart}`;

    // ══════════════════════════════════════════════════════════════════════
    //  EXCEL
    // ══════════════════════════════════════════════════════════════════════
    if (format === 'excel') {
      const wb = new ExcelJS.Workbook(); wb.creator='RAMP AMS';
      const ws = wb.addWorksheet('Daily Log');

      const NAVY   = {type:'pattern',pattern:'solid',fgColor:{argb:'FF1F3864'}};
      const LBLUE  = {type:'pattern',pattern:'solid',fgColor:{argb:'FFDCE6F1'}};
      const GREEN  = {type:'pattern',pattern:'solid',fgColor:{argb:'FF375623'}};
      const GREEN2 = {type:'pattern',pattern:'solid',fgColor:{argb:'FFA9D18E'}};
      const FILL_GOOD = {type:'pattern',pattern:'solid',fgColor:{argb:'FFD1FAE5'}};
      const FILL_LATE = {type:'pattern',pattern:'solid',fgColor:{argb:'FFFEE2E2'}};
      const COLOR_GOOD = 'FF047857';
      const COLOR_LATE = 'FFB91C1C';
      const CBDR = {
        top:{style:'thin',color:{argb:'FFCCCCCC'}}, bottom:{style:'thin',color:{argb:'FFCCCCCC'}},
        left:{style:'thin',color:{argb:'FFCCCCCC'}}, right:{style:'thin',color:{argb:'FFCCCCCC'}},
      };

     const COLS = ['Date','Check-In','Check-Out','Total Time','Duty Type','Leave Type'];

// Row 1 — employee info banner
ws.mergeCells(1,1,1,COLS.length);
Object.assign(ws.getCell(1,1),{
  value:headerLine,
  font:{bold:true,size:12,color:{argb:'FFFFFFFF'}},
  fill:NAVY,
  alignment:{horizontal:'left',vertical:'center'},
});
ws.getRow(1).height=22;

// Row 2 — filter/period line
ws.mergeCells(2,1,2,COLS.length);
Object.assign(ws.getCell(2,1),{
  value: `Filter: ${status}   |   Period: ${status==='Today Check-in' ? startDate : `${startDate} to ${endDate}`}`,
  font:{italic:true,size:9,color:{argb:'FF555555'}},
  alignment:{horizontal:'left',vertical:'center'},
});
ws.getRow(2).height=15;

// Row 3 — column headers (THIS is the block that must run, once, for ALL 6 columns)
COLS.forEach((h,i)=>{
  const c=ws.getCell(3,i+1);
  c.value = h;
  c.font  = {bold:true,size:10,color:{argb:'FF1F3864'}};
  c.fill  = LBLUE;
  c.border = CBDR;
  c.alignment = {horizontal:'center',vertical:'center'};
  ws.getColumn(i+1).width = i===0?12:i===3?12:16;
});

// Data rows start at row 4
rows.forEach((r,idx)=>{
  const rn=4+idx;
        [r.date,r.checkin,r.checkout,r.total,r.dutyType,r.leaveType].forEach((v,i)=>{
          const c=ws.getCell(rn,i+1);
          c.value=v||''; c.border=CBDR; c.font={size:10};
          c.alignment={horizontal:i===0?'left':'center',vertical:'center'};

          // Column 2 (index 1) = Check-In, Column 3 (index 2) = Check-Out
          if (i===1 && r.checkinFlag) {
            c.fill = r.checkinFlag==='good' ? FILL_GOOD : FILL_LATE;
            c.font = {size:10, bold:true, color:{argb: r.checkinFlag==='good' ? COLOR_GOOD : COLOR_LATE}};
          }
          if (i===2 && r.checkoutFlag) {
            c.fill = r.checkoutFlag==='good' ? FILL_GOOD : FILL_LATE;
            c.font = {size:10, bold:true, color:{argb: r.checkoutFlag==='good' ? COLOR_GOOD : COLOR_LATE}};
          }
        });
      });

      let r = 4+rows.length+1;
      ws.mergeCells(r,1,r,COLS.length);
      Object.assign(ws.getCell(r,1),{
        value:`Working Days: ${workingDays}  |  Holidays: ${holidays}  |  Leaves: ${leaves}  |  Missed Checkout: ${missedCheckout}  |  Absent: ${absent}  |  Total: ${totalDays} days`,
        font:{bold:true,size:10,color:{argb:'FFFFFFFF'}}, fill:GREEN, alignment:{horizontal:'left',vertical:'center'},
      });
      ws.getRow(r).height=18;

      r++;
      ws.mergeCells(r,1,r,COLS.length);
      Object.assign(ws.getCell(r,1),{
        value:`Approved: ${approved}  |  Pending: ${pending}  |  Rejected: ${rejected}`,
        font:{bold:true,size:10,color:{argb:'FF1F3864'}}, fill:GREEN2, alignment:{horizontal:'left',vertical:'center'},
      });
      ws.getRow(r).height=18;

      res.setHeader('Content-Type','application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
      res.setHeader('Content-Disposition',`attachment; filename="${fnameBase}.xlsx"`);
      res.setHeader('Access-Control-Expose-Headers','Content-Disposition');
      await wb.xlsx.write(res);
      return res.end();
    }

    // ══════════════════════════════════════════════════════════════════════
    //  PDF
    // ══════════════════════════════════════════════════════════════════════
    if (format === 'pdf') {
      const doc = new PDFDoc({size:'A4',layout:'portrait',margins:{top:30,bottom:30,left:30,right:30}});
      res.setHeader('Content-Type','application/pdf');
      res.setHeader('Content-Disposition',`attachment; filename="${fnameBase}.pdf"`);
      res.setHeader('Access-Control-Expose-Headers','Content-Disposition');
      doc.pipe(res);

      const ML=30, PW=doc.page.width-60;
      doc.rect(ML,ML,PW,22).fill('#1F3864');
      doc.fillColor('#FFFFFF').fontSize(11).font('Helvetica-Bold').text(headerLine,ML+6,ML+6,{width:PW-12});

      let y = ML+22;
      doc.fillColor('#555555').fontSize(8).font('Helvetica-Oblique')
         .text(`Filter: ${status}   |   Period: ${status==='Today Check-in' ? startDate : `${startDate} to ${endDate}`}`,ML,y+3,{width:PW});
      y += 16;

      const colX=[ML, ML+70, ML+150, ML+230, ML+310, ML+410];
      const colW=[70,80,80,80,100,80];
      doc.rect(ML,y,PW,16).fill('#DCE6F1').stroke('#AAAAAA');
      ['Date','Check-In','Check-Out','Total Time','Duty Type','Leave Type'].forEach((h,i)=>{
        doc.fillColor('#1F3864').fontSize(8).font('Helvetica-Bold').text(h,colX[i]+2,y+4,{width:colW[i]-4,align:'center'});
      });
      y+=16;
      rows.forEach((r,idx)=>{
        if (y+14>doc.page.height-100){doc.addPage();y=30;}
        doc.rect(ML,y,PW,14).fill(idx%2===0?'#FFFFFF':'#F7F7F7').stroke('#DDDDDD');
        [r.date,r.checkin,r.checkout,r.total,r.dutyType,r.leaveType].forEach((v,i)=>{
          let color = '#000000';
          if (i===1 && r.checkinFlag)  color = r.checkinFlag==='good'  ? '#047857' : '#B91C1C';
          if (i===2 && r.checkoutFlag) color = r.checkoutFlag==='good' ? '#047857' : '#B91C1C';
          doc.fillColor(color).fontSize(7.5).font(color==='#000000' ? 'Helvetica' : 'Helvetica-Bold')
             .text(String(v||''),colX[i]+2,y+3,{width:colW[i]-4,align:i===0?'left':'center',lineBreak:false,ellipsis:true});
        });
        y+=14;
      });

      y+=6;
      doc.rect(ML,y,PW,18).fill('#375623');
      doc.fillColor('#FFFFFF').fontSize(8).font('Helvetica-Bold')
         .text(`Working Days: ${workingDays}  |  Holidays: ${holidays}  |  Leaves: ${leaves}  |  Missed Checkout: ${missedCheckout}  |  Absent: ${absent}  |  Total: ${totalDays} days`,ML+6,y+5,{width:PW-12});
      y+=18;
      doc.rect(ML,y,PW,18).fill('#A9D18E');
      doc.fillColor('#1F3864').fontSize(8).font('Helvetica-Bold')
         .text(`Approved: ${approved}  |  Pending: ${pending}  |  Rejected: ${rejected}`,ML+6,y+5,{width:PW-12});

      doc.end();
      return;
    }

    res.status(400).json({success:false,message:'format must be excel or pdf'});
  } catch(err){
    console.error('[DailyLogExport]',err);
    res.status(500).json({success:false,message:'Export failed',error:err.message});
  }
});
// ══════════════════════════════════════════════════════════════════════════════
//  GET /api/reports/late-checkout          (preview — powers the "View" button)
//  GET /api/reports/late-checkout-export   (excel / pdf download)
//  "Late check-out" = checkout_time >= 18:30 (6:30 PM IST)
// ══════════════════════════════════════════════════════════════════════════════
const LATE_CHECKOUT_CUTOFF = '18:30';

const resolveLateCheckoutEmployees = async (req) => {
  const role = req.user.role;
  const { empId, managerId } = req.query;
  const EMP_SELECT = '_id name emp_id';
  let employees = [];

  if (role === 'employee') {
    const me = await User.findById(req.user.id).select(EMP_SELECT).lean();
    if (me) employees = [me];
  } else if (empId && String(empId).trim() !== '') {
    const specific = await User.findById(toObjId(empId)).select(EMP_SELECT).lean();
    if (specific) employees = [specific];
  } else if (managerId && String(managerId).trim() !== '') {
    employees = await User.find({ manager_id: toObjId(managerId), is_active: { $ne: false } })
      .select(EMP_SELECT).sort({ emp_id: 1 }).lean();
  } else if (role === 'manager') {
    employees = await User.find({ manager_id: toObjId(req.user.id), is_active: { $ne: false } })
      .select(EMP_SELECT).sort({ emp_id: 1 }).lean();
  } else {
    employees = await User.find({ role: 'employee', is_active: { $ne: false } })
      .select(EMP_SELECT).sort({ emp_id: 1 }).lean();
  }
  return employees;
};

const buildLateCheckoutRows = async ({ startDate, endDate, employees }) => {
  const recs = await AttendanceRecord.find({
    date:          { $gte: startDate, $lte: endDate },
    emp_id:        { $in: employees.map(e => e._id) },
    checkout_time: { $ne: null, $gte: LATE_CHECKOUT_CUTOFF },
  }).sort({ date: 1 }).lean();

  const empMap = {};
  for (const e of employees) empMap[String(e._id)] = e;

  return Promise.all(recs.map(async r => {
    const emp        = empMap[String(r.emp_id)];
    const checkinLoc  = await buildLocationText(r.location_address, r.latitude, r.longitude);
    const checkoutLoc = await buildLocationText(r.checkout_location_address, r.checkout_lat, r.checkout_lng);
    return {
      empCode:  emp?.emp_id || '',
      empName:  emp?.name   || '',
      date:     r.date,
      checkinLocationTime:  r.checkin_time
        ? `${checkinLoc || 'Address not captured'} (${r.checkin_time})`
        : (checkinLoc || ''),
      checkoutLocationTime: r.checkout_time
        ? `${checkoutLoc || 'Address not captured'} (${r.checkout_time})`
        : (checkoutLoc || ''),
      reason: (r.late_checkout_reason && r.late_checkout_reason.trim()) || 'No reason provided',
    };
  }));
};

router.get('/late-checkout',
  authenticate,
  authorize('super_admin','admin','hr','manager','employee'),
  async (req, res) => {
  try {
    const { startDate, endDate } = req.query;
    if (!startDate || !endDate)
      return res.status(400).json({ success:false, message:'startDate and endDate are required' });

    const employees = await resolveLateCheckoutEmployees(req);
    if (!employees.length)
      return res.status(404).json({ success:false, message:'No employees found' });

    const rows = await buildLateCheckoutRows({ startDate, endDate, employees });
    res.json({ success:true, data: rows, count: rows.length });
  } catch (err) {
    console.error('[LateCheckoutView]', err);
    res.status(500).json({ success:false, message:'Failed to load late check-out records', error: err.message });
  }
});

router.get('/late-checkout-export',
  authenticate,
  authorize('super_admin','admin','hr','manager','employee'),
  async (req, res) => {
  try {
    const { format = 'excel', empId } = req.query;
    const { startDate, endDate } = req.query;
    if (!startDate || !endDate)
      return res.status(400).json({ success:false, message:'startDate and endDate are required' });

    const employees = await resolveLateCheckoutEmployees(req);
    if (!employees.length)
      return res.status(404).json({ success:false, message:'No employees found' });

    const rows = await buildLateCheckoutRows({ startDate, endDate, employees });

    const sd = new Date(startDate+'T00:00:00+05:30');
    const ed = new Date(endDate  +'T00:00:00+05:30');
    const rangeLabel =
      `${ordinal(sd.getDate())} ${sd.toLocaleDateString('en-IN',{timeZone:IST,month:'short'})} ${sd.getFullYear()}` +
      ` To ` +
      `${ordinal(ed.getDate())} ${ed.toLocaleDateString('en-IN',{timeZone:IST,month:'long'})} ${ed.getFullYear()}`;

    const sanitize = s => String(s||'').trim().replace(/[^a-zA-Z0-9]+/g,'_').replace(/^_+|_+$/g,'');
    const singleEmp = employees.length === 1
      ? employees[0]
      : (empId ? employees.find(e => String(e._id) === String(empId)) : null);
    const fnameBase = singleEmp
      ? `${sanitize(singleEmp.name)}_${sanitize(singleEmp.emp_id)}_LateCheckout_${startDate}_to_${endDate}`
      : `BRP_LateCheckout_${startDate}_to_${endDate}`;

    if (format === 'excel') {
      const wb = new ExcelJS.Workbook(); wb.creator = 'RAMP AMS';
      const ws = wb.addWorksheet('Late Check-out');

      const NAVY = { type:'pattern', pattern:'solid', fgColor:{ argb:'FF1F3864' } };
      const HDR  = { type:'pattern', pattern:'solid', fgColor:{ argb:'FFDCE6F1' } };
      const EVEN = { type:'pattern', pattern:'solid', fgColor:{ argb:'FFFFFFFF' } };
      const ODD  = { type:'pattern', pattern:'solid', fgColor:{ argb:'FFF7F7F7' } };
      const CBDR = {
        top:{style:'thin',color:{argb:'FFCCCCCC'}}, bottom:{style:'thin',color:{argb:'FFCCCCCC'}},
        left:{style:'thin',color:{argb:'FFCCCCCC'}}, right:{style:'thin',color:{argb:'FFCCCCCC'}},
      };

      const COLS = [
        { header:'Emp Name',                     width:22 },
        { header:'Emp ID',                       width:14 },
        { header:'Check-in Location with Time',  width:46 },
        { header:'Check-out Location with Time', width:46 },
        { header:'Reason (Employee Response)',   width:38 },
      ];

      ws.mergeCells(1,1,1,COLS.length);
      Object.assign(ws.getCell(1,1), {
        value: `Late Check-out — ${rangeLabel}`,
        font:  { bold:true, size:13, color:{argb:'FFFFFFFF'} },
        fill:  NAVY,
        alignment: { horizontal:'center', vertical:'center' },
      });
      ws.getRow(1).height = 24;

      COLS.forEach((c,i)=>{
        ws.getColumn(i+1).width = c.width;
        const cell = ws.getCell(2,i+1);
        cell.value = c.header; cell.fill = HDR; cell.border = CBDR;
        cell.font  = { bold:true, size:10, color:{argb:'FF1F3864'} };
        cell.alignment = { horizontal:'center', vertical:'center', wrapText:true };
      });
      ws.getRow(2).height = 20;

      if (!rows.length) {
        ws.mergeCells(3,1,3,COLS.length);
        Object.assign(ws.getCell(3,1), {
          value: 'No late check-out records found for the selected period and filters.',
          font: { italic:true, size:10, color:{argb:'FF888888'} },
          alignment: { horizontal:'center', vertical:'center' },
        });
      } else {
        rows.forEach((r,idx)=>{
          const rn = 3+idx;
          const rf = idx%2===0 ? EVEN : ODD;
          [r.empName, r.empCode, r.checkinLocationTime, r.checkoutLocationTime, r.reason].forEach((v,i)=>{
            const c = ws.getCell(rn,i+1);
            c.value = v || ''; c.fill = rf; c.border = CBDR;
            c.font  = { size:9 };
            c.alignment = { horizontal: i<2?'center':'left', vertical:'center', wrapText: i>=2 };
          });
        });
      }

      ws.views = [{ state:'frozen', ySplit:2 }];
      ws.pageSetup = {
        paperSize:9, orientation:'landscape', fitToPage:true, fitToWidth:1, fitToHeight:0,
        printTitlesRow:'$1:$2',
        margins:{left:0.3,right:0.3,top:0.4,bottom:0.4,header:0.2,footer:0.2},
      };

      res.setHeader('Content-Type','application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
      res.setHeader('Content-Disposition',`attachment; filename="${fnameBase}.xlsx"`);
      res.setHeader('Access-Control-Expose-Headers','Content-Disposition');
      await wb.xlsx.write(res);
      return res.end();
    }

    if (format === 'pdf') {
      const doc = new PDFDoc({ size:'A3', layout:'landscape', margins:{top:28,bottom:28,left:28,right:28}, autoFirstPage:true });
      res.setHeader('Content-Type','application/pdf');
      res.setHeader('Content-Disposition',`attachment; filename="${fnameBase}.pdf"`);
      res.setHeader('Access-Control-Expose-Headers','Content-Disposition');
      doc.pipe(res);

      const ML = 28;
      const usableW = doc.page.width - ML*2;
      const colDefs = [
        { key:'empName',              header:'Emp Name',                     w:0.14 },
        { key:'empCode',               header:'Emp ID',                       w:0.08 },
        { key:'checkinLocationTime',  header:'Check-in Location with Time',  w:0.34 },
        { key:'checkoutLocationTime', header:'Check-out Location with Time', w:0.34 },
        { key:'reason',               header:'Reason (Employee Response)',   w:0.10 },
      ];
      const cw = colDefs.map(c => c.w*usableW);
      const HRH = 18, RH = 20;

      const drawHeader = (yy) => {
        doc.rect(ML,yy,usableW,20).fill('#1F3864');
        doc.fillColor('#FFFFFF').fontSize(11).font('Helvetica-Bold')
           .text(`Late Check-out — ${rangeLabel}`, ML, yy+5, { width:usableW, align:'center' });
        yy += 20;
        let cx = ML;
        colDefs.forEach((c,i)=>{
          doc.rect(cx,yy,cw[i],HRH).fill('#DCE6F1').stroke('#AAAAAA');
          doc.fillColor('#1F3864').fontSize(8).font('Helvetica-Bold')
             .text(c.header, cx+3, yy+4, { width:cw[i]-6, align:'center' });
          cx += cw[i];
        });
        return yy+HRH;
      };

      let y = drawHeader(ML);

      if (!rows.length) {
        doc.rect(ML,y,usableW,RH).fill('#FFFFFF').stroke('#CCCCCC');
        doc.fillColor('#888888').fontSize(9).font('Helvetica-Oblique')
           .text('No late check-out records found for the selected period and filters.', ML, y+5, { width:usableW, align:'center' });
        y += RH;
      } else {
        rows.forEach((r,idx)=>{
          if (y+RH > doc.page.height-40) {
            doc.addPage({size:'A3',layout:'landscape',margins:{top:28,bottom:28,left:28,right:28}});
            y = drawHeader(28);
          }
          const bg = idx%2===0 ? '#FFFFFF' : '#F7F7F7';
          doc.rect(ML,y,usableW,RH).fill(bg).stroke('#DDDDDD');
          let cx = ML;
          [r.empName, r.empCode, r.checkinLocationTime, r.checkoutLocationTime, r.reason].forEach((v,i)=>{
            doc.rect(cx,y,cw[i],RH).stroke('#DDDDDD');
            doc.fillColor('#000000').fontSize(7).font('Helvetica')
               .text(String(v||''), cx+3, y+4, { width:cw[i]-6, align:i<2?'center':'left' });
            cx += cw[i];
          });
          y += RH;
        });
      }

      doc.end();
      return;
    }

    res.status(400).json({ success:false, message:'format must be excel or pdf' });
  } catch (err) {
    console.error('[LateCheckoutExport]', err);
    res.status(500).json({ success:false, message:'Late check-out export failed', error: err.message });
  }
});
module.exports = router;